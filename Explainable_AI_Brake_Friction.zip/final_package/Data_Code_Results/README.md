# Data and Code Repository
## An Explainable AI Framework for Krauss-Test-Based Performance Prediction and
## Multi-Objective Optimization of Rubber-Based Brake Friction Materials Using Taguchi L27 Design

This repository accompanies the manuscript and provides everything needed to
reproduce the reported analysis pipeline: input datasets, analysis code, and
result tables/figure-source data, organized to match the manuscript's
Tables and Figures and ready for import into OriginPro or any plotting
software.

> **Important note on the data.** As stated in the manuscript's Abstract and
> Section 7 (Future Scope), the reported dataset is a **validated
> physics-constrained synthetic case study**, not measurements from a
> physical Krauss dynamometer. The files in `data/` and the `_regenerated`
> files in `results/` are produced by the scripts in `code/`, which
> implement the same procedure described in the manuscript (Sections
> 3.6-3.9) but will not reproduce the manuscript's exact reported numbers
> bit-for-bit on every run (different random seeds / package versions give
> slightly different values). The manuscript's **exact published numbers**
> are preserved separately in `results/table_data/*_AS_REPORTED.csv` for
> archival and citation purposes.

## Repository structure

```
repo/
├── README.md                         <- this file
├── data/                              <- input datasets
│   ├── table1_factors_levels.csv          Factor levels used in the L27 design
│   ├── table2_L27_design_matrix.csv       27-run Taguchi design matrix (physical units)
│   ├── dataset_81_baseline_krauss_observations.csv   27 runs x 3 reps, reconstructed
│   │                                                   from Table 4 means + Table 3 SDs
│   └── dataset_1200_AIready_augmented.csv  81 baseline + 1119 synthetic = 1200 rows,
│                                            physics-constrained and KS/Wasserstein-validated
│
├── code/                              <- fully runnable Python pipeline (run in order)
│   ├── requirements.txt
│   ├── 01_generate_taguchi_L27_design.py
│   ├── 02_generate_baseline_dataset.py
│   ├── 03_physics_constrained_augmentation.py
│   ├── 04_ml_model_comparison.py
│   ├── 05_shap_explainability.py
│   ├── 06_nsga2_optimization.py
│   ├── 07_confirmation_test.py
│   └── 08_supplementary_figure_data.py
│
└── results/                           <- ready for OriginPro / manuscript figures
    ├── table_data/
    │   ├── table1_factors_levels.csv
    │   ├── table2_L27_design_matrix.csv
    │   ├── table3_synthetic_validation_AS_REPORTED.csv
    │   ├── table3_synthetic_validation_regenerated.csv
    │   ├── table4_mean_krauss_results_AS_REPORTED.csv
    │   ├── table5a_anova_CoF_AS_REPORTED.csv
    │   ├── table5b_anova_SWR_AS_REPORTED.csv
    │   ├── table6_ml_model_comparison_AS_REPORTED.csv
    │   ├── table6_ml_model_comparison_regenerated.csv
    │   ├── table7_shap_importance_AS_REPORTED.csv
    │   ├── table7_shap_importance_regenerated.csv
    │   ├── table8_recommended_formulation_AS_REPORTED.csv
    │   ├── table8_recommended_formulation_regenerated.csv
    │   ├── table9_confirmation_results_AS_REPORTED.csv
    │   ├── table9_confirmation_results_regenerated.csv
    │   └── pareto_set_120.csv
    ├── figure_data/                    <- CSV source data behind each figure (for OriginPro etc.)
    │   ├── fig5_cof_vs_braking_cycle.csv
    │   ├── fig6_temperature_vs_braking_cycle.csv
    │   ├── fig7_sn_main_effects.csv
    │   ├── fig9_exp_vs_synthetic_histograms.csv
    │   ├── fig10_predicted_vs_measured_CoF.csv
    │   ├── fig11_predicted_vs_measured_SWR.csv
    │   ├── fig12_shap_global_importance.csv
    │   ├── fig13_shap_dependence_NR_CoF.csv
    │   ├── fig13_shap_dependence_NBR_SWR.csv
    │   ├── fig14_shap_interaction_CoF.csv
    │   ├── fig15_pareto_front.csv
    │   └── fig16_confirmation_comparison.csv
    └── figures/                        <- rendered PNG plots (ready to view/embed directly)
        ├── fig05_cof_vs_braking_cycle.png
        ├── fig06_temperature_vs_braking_cycle.png
        ├── fig07_sn_main_effects.png
        ├── fig08_anova_contribution.png
        ├── fig09_exp_vs_synthetic_distributions.png
        ├── fig10_predicted_vs_measured_CoF.png
        ├── fig11_predicted_vs_measured_SWR.png
        ├── fig12_shap_global_importance.png
        ├── fig13_shap_dependence.png
        ├── fig14_shap_interaction_map.png
        ├── fig15_pareto_front.png
        └── fig16_confirmation_comparison.png
```

(Figures 1-4 are schematic/workflow diagrams and the L27 design table with
no additional plotted numeric series beyond `table2_L27_design_matrix.csv`;
no figure-data file is produced for them.)

## How to reproduce the pipeline

```bash
cd code
pip install -r requirements.txt --break-system-packages   # or use a virtualenv
python 01_generate_taguchi_L27_design.py
python 02_generate_baseline_dataset.py
python 03_physics_constrained_augmentation.py
python 04_ml_model_comparison.py
python 05_shap_explainability.py
python 06_nsga2_optimization.py
python 07_confirmation_test.py
python 08_supplementary_figure_data.py
python 09_generate_plots.py
```

Each script reads its inputs from `../data/` or `../results/` and writes its
outputs there, so they must be run in numerical order the first time.
Script 09 renders the CSV data from scripts 01-08 into publication-style
PNG plots in `results/figures/`, matching Figures 5-16 of the manuscript
(matplotlib only, `Agg` backend, no display required).

## Importing into OriginPro

All files in `results/` are plain, comma-separated CSVs with a single header
row of plain-text column names — the format OriginPro's
**File > Import > Import Wizard / Multiple ASCII** expects with no
extra configuration. For grouped/faceted plots (e.g. Figure 5's three
formulations, or Table 6's per-response model comparison), use Origin's
"Group by" / worksheet-column-subset tools on the `Formulation`, `Response`,
or `Model` label column to split series before plotting.

## Mapping to the manuscript

| Manuscript item | File(s) |
|---|---|
| Table 1 | `data/table1_factors_levels.csv` |
| Table 2 / Figure 4 | `data/table2_L27_design_matrix.csv` |
| Table 3 | `results/table_data/table3_synthetic_validation_AS_REPORTED.csv` |
| Table 4 | `results/table_data/table4_mean_krauss_results_AS_REPORTED.csv`, `data/dataset_81_baseline_krauss_observations.csv` |
| Table 5a/5b, Figure 8 | `results/table_data/table5a_anova_CoF_AS_REPORTED.csv`, `table5b_anova_SWR_AS_REPORTED.csv` |
| Figure 5, 6 | `results/figure_data/fig5_cof_vs_braking_cycle.csv`, `fig6_temperature_vs_braking_cycle.csv` |
| Figure 7 | `results/figure_data/fig7_sn_main_effects.csv` |
| Figure 9 | `results/figure_data/fig9_exp_vs_synthetic_histograms.csv` |
| Table 6, Figure 10/11 | `results/table_data/table6_ml_model_comparison_AS_REPORTED.csv`, `results/figure_data/fig10_*`, `fig11_*` |
| Table 7, Figure 12/13/14 | `results/table_data/table7_shap_importance_AS_REPORTED.csv`, `results/figure_data/fig12_*`, `fig13_*`, `fig14_*` |
| Table 8, Figure 15 | `results/table_data/table8_recommended_formulation_AS_REPORTED.csv`, `results/table_data/pareto_set_120.csv`, `results/figure_data/fig15_*` |
| Table 9, Figure 16 | `results/table_data/table9_confirmation_results_AS_REPORTED.csv`, `results/figure_data/fig16_*` |
| Full 1200-sample AI-ready dataset | `data/dataset_1200_AIready_augmented.csv` |

## Citation

If you use this repository, please cite the manuscript (full citation to be
added once the DOI/volume/issue is assigned) and, if applicable, this
repository's own DOI once deposited (e.g., via Zenodo/Figshare).

## License

Add your chosen license here (e.g., CC-BY 4.0 for data, MIT for code) prior
to public deposition.
