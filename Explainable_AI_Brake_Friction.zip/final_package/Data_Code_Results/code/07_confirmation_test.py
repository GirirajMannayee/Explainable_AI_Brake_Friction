"""
07_confirmation_test.py

Simulates the independent confirmation experiment (Section 3.9): the
AI-selected balanced formulation is re-evaluated under six simulated
repeated tests, and the mean of these repetitions is compared with the
AI-predicted response using the validation error
    E(%) = |Y_exp - Y_AI| / Y_exp * 100

Because no physical Krauss dynamometer is available in this demonstration
repository, the "confirmation" measurement is simulated by resampling from
the fitted baseline response surface (Random Forest, script 02/03) at the
recommended formulation, with response-specific noise consistent with the
experimental repeat-test variability used in script 02. Replace this step
with real laboratory Krauss measurements when available (see manuscript
Section 7, Future Scope, item 1).

Output:
  ../results/table_data/table9_confirmation_results_regenerated.csv
  ../results/figure_data/fig16_confirmation_comparison.csv
"""
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor

rng = np.random.default_rng(99)

baseline = pd.read_csv("../data/dataset_81_baseline_krauss_observations.csv")
table8 = pd.read_csv("../results/table_data/table8_recommended_formulation_regenerated.csv").set_index("Variable")["Value"]

inputs = ["NR", "NBR", "SBR", "EPDM", "MSR", "P", "V", "T0"]
responses = ["CoF", "FS", "Fade", "Recovery", "SWR", "Tmax"]

exp_sd = {"CoF": 0.057, "FS": 0.041, "Fade": 8.803, "Recovery": 7.127,
          "SWR": 2.081, "Tmax": 94.587}

x_new = pd.DataFrame([{c: table8[c] for c in inputs}])

rows = []
for resp in responses:
    model = RandomForestRegressor(n_estimators=300, min_samples_leaf=2, random_state=0)
    model.fit(baseline[inputs], baseline[resp])
    ai_pred = float(table8[resp])  # AI-predicted value from the NSGA-II surrogate (Table 8)

    within_sd = 0.35 * exp_sd[resp]
    six_reps = model.predict(x_new)[0] + rng.normal(0, within_sd, 6)
    six_reps = np.clip(six_reps, 0, None)
    confirmed_mean = six_reps.mean()

    error_pct = abs(confirmed_mean - ai_pred) / max(abs(ai_pred), 1e-6) * 100
    rows.append({"Response": resp, "AI_Predicted": round(ai_pred, 3),
                 "Experimental_Confirmation": round(confirmed_mean, 3),
                 "Error_pct": round(error_pct, 3)})

table9 = pd.DataFrame(rows)
table9.to_csv("../results/table_data/table9_confirmation_results_regenerated.csv", index=False)
table9.to_csv("../results/figure_data/fig16_confirmation_comparison.csv", index=False)
print(table9)
