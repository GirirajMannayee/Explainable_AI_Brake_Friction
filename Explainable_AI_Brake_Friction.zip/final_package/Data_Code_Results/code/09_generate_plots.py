"""
09_generate_plots.py

Renders publication-style PNG plots from the CSV data produced by the
earlier scripts, matching the manuscript's Figures 5-16. Uses matplotlib
only (no seaborn dependency) so it runs in any standard Python/scientific
environment.

Output: ../results/figures/fig05_*.png ... fig16_*.png
"""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

OUT = "../results/figures"
plt.rcParams.update({
    "font.size": 10, "figure.dpi": 150, "savefig.dpi": 150,
    "axes.grid": True, "grid.alpha": 0.3,
})

# ---------------------------------------------------------------- Figure 5
df = pd.read_csv("../results/figure_data/fig5_cof_vs_braking_cycle.csv")
fig, ax = plt.subplots(figsize=(6.5, 4.2))
for label, g in df.groupby("Formulation"):
    ax.plot(g["Cycle_fraction"], g["CoF"], label=label, linewidth=1.6)
ax.set_xlabel("Braking-cycle fraction")
ax.set_ylabel("Coefficient of friction, CoF")
ax.set_title("Figure 5. Coefficient-of-friction response vs. braking cycle")
ax.legend(fontsize=8)
fig.tight_layout()
fig.savefig(f"{OUT}/fig05_cof_vs_braking_cycle.png")
plt.close(fig)

# ---------------------------------------------------------------- Figure 6
df = pd.read_csv("../results/figure_data/fig6_temperature_vs_braking_cycle.csv")
fig, ax = plt.subplots(figsize=(6.5, 4.2))
for label, g in df.groupby("Formulation"):
    ax.plot(g["Cycle_fraction"], g["Temperature_C"], label=label, linewidth=1.6)
ax.set_xlabel("Braking-cycle fraction")
ax.set_ylabel("Interface temperature (degC)")
ax.set_title("Figure 6. Temperature evolution during Krauss testing")
ax.legend(fontsize=8)
fig.tight_layout()
fig.savefig(f"{OUT}/fig06_temperature_vs_braking_cycle.png")
plt.close(fig)

# ---------------------------------------------------------------- Figure 7
df = pd.read_csv("../results/figure_data/fig7_sn_main_effects.csv")
fig, axes = plt.subplots(1, 2, figsize=(10, 4.2))
for ax, resp in zip(axes, ["CoF", "SWR"]):
    g = df[df["Response"] == resp].sort_values("Rank")
    colors = ["#2b6cb0" if r == "reported" else "#a0aec0" for r in g["Reported_or_estimated"]]
    ax.bar(g["Factor"], g["Delta_dB"], color=colors)
    ax.set_title(f"S/N main effects: {resp}")
    ax.set_ylabel("Delta (dB)")
    ax.tick_params(axis="x", rotation=45)
fig.suptitle("Figure 7. Taguchi main-effects and S/N-ratio plots\n"
              "(blue = value reported in manuscript text; grey = estimated for minor factors)",
              fontsize=9)
fig.tight_layout()
fig.savefig(f"{OUT}/fig07_sn_main_effects.png")
plt.close(fig)

# ---------------------------------------------------------------- Figure 8
t5a = pd.read_csv("../results/table_data/table5a_anova_CoF_AS_REPORTED.csv")
t5b = pd.read_csv("../results/table_data/table5b_anova_SWR_AS_REPORTED.csv")
t5a = t5a[t5a["Factor"] != "Error"]
t5b = t5b[t5b["Factor"] != "Error"]
fig, axes = plt.subplots(1, 2, figsize=(10, 4.2))
axes[0].bar(t5a["Factor"], t5a["Contribution_pct"], color="#3182ce")
axes[0].set_title("ANOVA contribution: Coefficient of friction")
axes[0].set_ylabel("Contribution (%)")
axes[1].bar(t5b["Factor"], t5b["Contribution_pct"], color="#dd6b20")
axes[1].set_title("ANOVA contribution: Specific wear rate")
axes[1].set_ylabel("Contribution (%)")
fig.suptitle("Figure 8. ANOVA contribution of formulation and operating parameters")
fig.tight_layout()
fig.savefig(f"{OUT}/fig08_anova_contribution.png")
plt.close(fig)

# ---------------------------------------------------------------- Figure 9
df = pd.read_csv("../results/figure_data/fig9_exp_vs_synthetic_histograms.csv")
responses = df["Response"].unique()
fig, axes = plt.subplots(2, 3, figsize=(12, 7))
for ax, resp in zip(axes.flat, responses):
    g = df[df["Response"] == resp]
    width = (g["Bin_center"].iloc[1] - g["Bin_center"].iloc[0]) * 0.4
    ax.bar(g["Bin_center"] - width/2, g["Experimental_count"], width=width, label="Experimental", color="#2b6cb0")
    ax.bar(g["Bin_center"] + width/2, g["Synthetic_count_scaled"], width=width, label="Synthetic", color="#e53e3e")
    ax.set_title(resp, fontsize=9)
axes.flat[0].legend(fontsize=7)
fig.suptitle("Figure 9. Experimental versus synthetic-data distributions")
fig.tight_layout()
fig.savefig(f"{OUT}/fig09_exp_vs_synthetic_distributions.png")
plt.close(fig)

# ------------------------------------------------------------ Figures 10/11
for fig_num, resp, fname in [("10", "CoF", "fig10_predicted_vs_measured_CoF.csv"),
                              ("11", "SWR", "fig11_predicted_vs_measured_SWR.csv")]:
    df = pd.read_csv(f"../results/figure_data/{fname}")
    fig, ax = plt.subplots(figsize=(5, 5))
    ax.scatter(df["Measured"], df["Predicted"], s=18, alpha=0.6, color="#2b6cb0")
    lims = [min(df["Measured"].min(), df["Predicted"].min()),
            max(df["Measured"].max(), df["Predicted"].max())]
    ax.plot(lims, lims, "k--", linewidth=1, label="1:1 line")
    ax.set_xlabel(f"Measured {resp}")
    ax.set_ylabel(f"Predicted {resp}")
    ax.set_title(f"Figure {fig_num}. AI prediction: measured vs. predicted {resp}")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(f"{OUT}/fig{fig_num}_predicted_vs_measured_{resp}.png")
    plt.close(fig)

# ---------------------------------------------------------------- Figure 12
df = pd.read_csv("../results/figure_data/fig12_shap_global_importance.csv", index_col=0)
fig, ax = plt.subplots(figsize=(7, 4.5))
df.plot(kind="bar", ax=ax)
ax.set_ylabel("Mean |SHAP value|")
ax.set_title("Figure 12. SHAP global feature-importance plot")
ax.legend(fontsize=7, ncol=3)
fig.tight_layout()
fig.savefig(f"{OUT}/fig12_shap_global_importance.png")
plt.close(fig)

# ---------------------------------------------------------------- Figure 13
d1 = pd.read_csv("../results/figure_data/fig13_shap_dependence_NR_CoF.csv")
d2 = pd.read_csv("../results/figure_data/fig13_shap_dependence_NBR_SWR.csv")
fig, axes = plt.subplots(1, 2, figsize=(10, 4.2))
sc1 = axes[0].scatter(d1["NR"], d1["SHAP_value_CoF"], c=d1["T0"], cmap="coolwarm", s=10)
axes[0].set_xlabel("NR (wt.%)"); axes[0].set_ylabel("SHAP value (CoF)")
axes[0].set_title("NR -> CoF (colour = T0)")
fig.colorbar(sc1, ax=axes[0], label="T0 (degC)")
sc2 = axes[1].scatter(d2["NBR"], d2["SHAP_value_SWR"], c=d2["T0"], cmap="coolwarm", s=10)
axes[1].set_xlabel("NBR (wt.%)"); axes[1].set_ylabel("SHAP value (SWR)")
axes[1].set_title("NBR -> SWR (colour = T0)")
fig.colorbar(sc2, ax=axes[1], label="T0 (degC)")
fig.suptitle("Figure 13. SHAP dependence plots for the dominant rubber constituents")
fig.tight_layout()
fig.savefig(f"{OUT}/fig13_shap_dependence.png")
plt.close(fig)

# ---------------------------------------------------------------- Figure 14
df = pd.read_csv("../results/figure_data/fig14_shap_interaction_CoF.csv", index_col=0)
fig, ax = plt.subplots(figsize=(6.4, 5.6))
im = ax.imshow(df.values, cmap="viridis")
ax.set_xticks(range(len(df.columns))); ax.set_xticklabels(df.columns, rotation=45)
ax.set_yticks(range(len(df.index))); ax.set_yticklabels(df.index)
fig.colorbar(im, ax=ax, label="Mean |SHAP interaction value|")
ax.set_title("Figure 14. SHAP interaction map\n(coefficient of friction)", fontsize=10)
fig.tight_layout()
fig.savefig(f"{OUT}/fig14_shap_interaction_map.png")
plt.close(fig)

# ---------------------------------------------------------------- Figure 15
df = pd.read_csv("../results/table_data/pareto_set_120.csv")
rec = pd.read_csv("../results/table_data/table8_recommended_formulation_regenerated.csv").set_index("Variable")["Value"]
fig, axes = plt.subplots(1, 2, figsize=(10, 4.5))
axes[0].scatter(df["SWR"], df["FS"], s=20, color="#2b6cb0", label="Pareto set")
axes[0].scatter(rec["SWR"], rec["FS"], marker="*", s=220, color="#e53e3e", label="Recommended")
axes[0].set_xlabel("Specific wear rate (x1e-7 mm3/N.m)"); axes[0].set_ylabel("Friction stability, FS")
axes[0].legend(fontsize=8)
axes[1].scatter(df["Tmax"], df["Recovery"], s=20, color="#2b6cb0", label="Pareto set")
axes[1].scatter(rec["Tmax"], rec["Recovery"], marker="*", s=220, color="#e53e3e", label="Recommended")
axes[1].set_xlabel("Max interface temperature (degC)"); axes[1].set_ylabel("Recovery (%)")
axes[1].legend(fontsize=8)
fig.suptitle("Figure 15. NSGA-II Pareto front (star = recommended balanced formulation)")
fig.tight_layout()
fig.savefig(f"{OUT}/fig15_pareto_front.png")
plt.close(fig)

# ---------------------------------------------------------------- Figure 16
df = pd.read_csv("../results/figure_data/fig16_confirmation_comparison.csv")
fig, axes = plt.subplots(1, len(df), figsize=(2.1 * len(df), 4.2), sharey=False)
for ax, (_, row) in zip(axes, df.iterrows()):
    vals = [row["AI_Predicted"], row["Experimental_Confirmation"]]
    ax.bar(["AI", "Confirmed"], vals, color=["#2b6cb0", "#dd6b20"])
    ax.set_title(row["Response"], fontsize=10)
    ax.set_ylim(0, max(vals) * 1.3)
    ax.text(0.5, 0.93, f"{row['Error_pct']:.1f}% error", ha="center",
            transform=ax.transAxes, fontsize=8)
fig.suptitle("Figure 16. Predicted vs. experimentally validated optimum formulation")
fig.tight_layout()
fig.savefig(f"{OUT}/fig16_confirmation_comparison.png")
plt.close(fig)

print("All figures written to", OUT)
