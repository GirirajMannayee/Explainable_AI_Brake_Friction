"""
03_physics_constrained_augmentation.py

Builds the physics-constrained synthetic-data augmentation pipeline
(Section 3.6 of the manuscript):
  1. Fit a smooth response-surface (Random Forest) to the 81 baseline
     observations for each of the six responses.
  2. Sample candidate input vectors uniformly within the experimental
     ranges of the 8 design variables.
  3. Predict responses with the fitted surrogate and add small
     response-appropriate noise.
  4. Retain only candidates satisfying the explicit physical constraints:
       (i)   22 <= NR+NBR+SBR+EPDM+MSR <= 40 wt.%
       (ii)  SWR > 0
       (iii) 0 <= Fade <= 100
       (iv)  0 <= Recovery <= 100
       (v)   0.25 <= CoF <= 0.60
  5. Validate distributional similarity to the 81-observation baseline via
     the Kolmogorov-Smirnov test and Wasserstein distance (Table 3).
  6. Combine 81 baseline + a random subsample of validated synthetic rows
     into the final 1200-sample AI-ready dataset.

Output:
  ../data/dataset_1200_AIready_augmented.csv
  ../results/table_data/table3_synthetic_validation_regenerated.csv
"""
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from scipy.stats import ks_2samp, wasserstein_distance

rng = np.random.default_rng(7)

baseline = pd.read_csv("../data/dataset_81_baseline_krauss_observations.csv")
inputs = ["NR", "NBR", "SBR", "EPDM", "MSR", "P", "V", "T0"]
responses = ["CoF", "FS", "Fade", "Recovery", "SWR", "Tmax"]

X = baseline[inputs].values
surrogates = {}
for resp in responses:
    y = baseline[resp].values
    model = RandomForestRegressor(n_estimators=300, min_samples_leaf=2, random_state=0)
    model.fit(X, y)
    surrogates[resp] = model

ranges = {c: (baseline[c].min(), baseline[c].max()) for c in inputs}

N_CANDIDATES = 2200
cand = pd.DataFrame({
    c: rng.uniform(lo, hi, N_CANDIDATES) for c, (lo, hi) in ranges.items()
})

noise_frac = {"CoF": 0.03, "FS": 0.02, "Fade": 0.05, "Recovery": 0.02, "SWR": 0.05, "Tmax": 0.03}
for resp in responses:
    pred = surrogates[resp].predict(cand[inputs].values)
    sd = noise_frac[resp] * baseline[resp].std()
    cand[resp] = pred + rng.normal(0, sd, N_CANDIDATES)

# --- Physical constraints -------------------------------------------------
total_rubber = cand[["NR", "NBR", "SBR", "EPDM", "MSR"]].sum(axis=1)
mask = (
    (total_rubber >= 22) & (total_rubber <= 40) &
    (cand["SWR"] > 0) &
    (cand["Fade"] >= 0) & (cand["Fade"] <= 100) &
    (cand["Recovery"] >= 0) & (cand["Recovery"] <= 100) &
    (cand["CoF"] >= 0.25) & (cand["CoF"] <= 0.60)
)
retained = cand[mask].reset_index(drop=True)
print(f"Retained {len(retained)}/{N_CANDIDATES} candidates "
      f"({100*len(retained)/N_CANDIDATES:.1f}%) satisfying physical constraints.")

# --- Distributional validation (Table 3) ----------------------------------
val_rows = []
for resp in responses:
    exp_vals = baseline[resp].values
    syn_vals = retained[resp].values
    ks_stat, ks_p = ks_2samp(exp_vals, syn_vals)
    wd = wasserstein_distance(exp_vals, syn_vals)
    val_rows.append({
        "Response": resp,
        "Exp_mean": exp_vals.mean(), "Synth_mean": syn_vals.mean(),
        "Exp_SD": exp_vals.std(), "Synth_SD": syn_vals.std(),
        "KS_statistic": ks_stat, "KS_pvalue": ks_p, "Wasserstein_dist": wd,
    })
table3 = pd.DataFrame(val_rows).round(3)
table3.to_csv("../results/table_data/table3_synthetic_validation_regenerated.csv", index=False)
print(table3)

# --- Assemble final 1200-sample AI-ready dataset --------------------------
n_needed = 1200 - len(baseline)
synth_sample = retained.sample(n=min(n_needed, len(retained)), random_state=1).reset_index(drop=True)

baseline_tagged = baseline[inputs + responses].copy()
baseline_tagged["Source"] = "experimental_baseline"
synth_sample_tagged = synth_sample[inputs + responses].copy()
synth_sample_tagged["Source"] = "physics_constrained_synthetic"

final = pd.concat([baseline_tagged, synth_sample_tagged], ignore_index=True)
final.insert(0, "Sample_ID", np.arange(1, len(final) + 1))
final.to_csv("../data/dataset_1200_AIready_augmented.csv", index=False)
print(f"Final AI-ready dataset: {len(final)} samples "
      f"({(final['Source']=='experimental_baseline').sum()} experimental + "
      f"{(final['Source']=='physics_constrained_synthetic').sum()} synthetic)")
