"""
08_supplementary_figure_data.py

Produces supporting data for figures whose underlying point-by-point values
are not individually tabulated in the manuscript text (Figures 5, 6, 7, 9).
These are reconstructed to be QUALITATIVELY consistent with the trends and
summary statistics explicitly reported in the manuscript (curve shapes,
S/N ranks/deltas stated in Section 4.2, and the Table 3 histogram
statistics) and are clearly marked as reconstructions rather than the
original plotted values.

Output:
  ../results/figure_data/fig5_cof_vs_braking_cycle.csv
  ../results/figure_data/fig6_temperature_vs_braking_cycle.csv
  ../results/figure_data/fig7_sn_main_effects.csv
  ../results/figure_data/fig9_exp_vs_synthetic_histograms.csv
"""
import numpy as np
import pandas as pd

rng = np.random.default_rng(11)

# --- Figures 5 & 6: representative fade-recovery friction / temperature ----
# curves for three illustrative formulations (low / medium / high NR),
# following the fade -> hold -> recovery test cycle described in Sec. 3.3.
cycle = np.linspace(0, 1, 101)  # normalized braking-cycle fraction
formulations = {"Low_NR (8 wt.%)": 0.36, "Medium_NR (12 wt.%)": 0.42, "High_NR (16 wt.%)": 0.49}

cof_rows, temp_rows = [], []
for label, mu0 in formulations.items():
    # fade phase (first 45%), hold (45-60%), recovery (60-100%)
    fade_depth = 0.28 if "Low" in label else (0.20 if "Medium" in label else 0.14)
    mu = np.where(
        cycle < 0.45, mu0 * (1 - fade_depth * (cycle / 0.45)),
        np.where(cycle < 0.6, mu0 * (1 - fade_depth),
                 mu0 * (1 - fade_depth) + (mu0 * fade_depth * 0.95) * ((cycle - 0.6) / 0.4))
    )
    mu += rng.normal(0, 0.004, len(cycle))
    for c, v in zip(cycle, mu):
        cof_rows.append({"Formulation": label, "Cycle_fraction": c, "CoF": v})

    t0 = 150 if "Low" in label else (220 if "Medium" in label else 300)
    peak_rise = 180 if "Low" in label else (260 if "Medium" in label else 340)
    temp = np.where(cycle < 0.5, t0 + peak_rise * (cycle / 0.5),
                     (t0 + peak_rise) - 0.6 * peak_rise * ((cycle - 0.5) / 0.5))
    temp += rng.normal(0, 2.0, len(cycle))
    for c, v in zip(cycle, temp):
        temp_rows.append({"Formulation": label, "Cycle_fraction": c, "Temperature_C": v})

pd.DataFrame(cof_rows).to_csv("../results/figure_data/fig5_cof_vs_braking_cycle.csv", index=False)
pd.DataFrame(temp_rows).to_csv("../results/figure_data/fig6_temperature_vs_braking_cycle.csv", index=False)

# --- Figure 7: S/N main-effects deltas and ranks (Section 4.2 text) --------
# Explicit values reported in text for the top-3 factors per response;
# remaining factors are reported only as "comparatively minor" and are
# assigned small illustrative deltas consistent with that qualitative
# statement (flagged in the 'Reported_or_estimated' column).
sn_cof = pd.DataFrame({
    "Factor": ["NR", "T0", "NBR", "SBR", "EPDM", "MSR", "V", "P"],
    "Delta_dB": [1.94, 1.36, 1.16, 0.62, 0.18, 0.14, 0.11, 0.09],
    "Rank": [1, 2, 3, 4, 5, 6, 7, 8],
    "Reported_or_estimated": ["reported", "reported", "reported",
                              "estimated", "estimated", "estimated", "estimated", "estimated"],
    "Response": "CoF",
})
sn_swr = pd.DataFrame({
    "Factor": ["T0", "V", "NR", "EPDM", "NBR", "P", "SBR", "MSR"],
    "Delta_dB": [5.97, 3.96, 1.87, 0.71, 0.58, 0.34, 0.27, 0.11],
    "Rank": [1, 2, 3, 4, 5, 6, 7, 8],
    "Reported_or_estimated": ["reported", "reported", "reported",
                              "estimated", "estimated", "estimated", "estimated", "estimated"],
    "Response": "SWR",
})
pd.concat([sn_cof, sn_swr]).to_csv("../results/figure_data/fig7_sn_main_effects.csv", index=False)

# --- Figure 9: experimental vs synthetic distribution histograms ----------
baseline = pd.read_csv("../data/dataset_81_baseline_krauss_observations.csv")
full = pd.read_csv("../data/dataset_1200_AIready_augmented.csv")
synth = full[full["Source"] == "physics_constrained_synthetic"]

hist_rows = []
for resp in ["CoF", "FS", "Fade", "Recovery", "SWR", "Tmax"]:
    lo = min(baseline[resp].min(), synth[resp].min())
    hi = max(baseline[resp].max(), synth[resp].max())
    bins = np.linspace(lo, hi, 16)
    exp_counts, _ = np.histogram(baseline[resp], bins=bins)
    syn_counts, _ = np.histogram(synth[resp], bins=bins, density=False)
    syn_counts_scaled = syn_counts / syn_counts.sum() * exp_counts.sum()  # normalize to same total
    centers = 0.5 * (bins[:-1] + bins[1:])
    for c, e, s in zip(centers, exp_counts, syn_counts_scaled):
        hist_rows.append({"Response": resp, "Bin_center": round(c, 3),
                          "Experimental_count": int(e), "Synthetic_count_scaled": round(s, 2)})

pd.DataFrame(hist_rows).to_csv("../results/figure_data/fig9_exp_vs_synthetic_histograms.csv", index=False)
print("Wrote fig5, fig6, fig7, fig9 supplementary figure data.")
