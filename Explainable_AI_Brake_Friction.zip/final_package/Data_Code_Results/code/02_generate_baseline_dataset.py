"""
02_generate_baseline_dataset.py

Reconstructs the 81-observation (27 runs x 3 repetitions) physics-constrained
baseline dataset reported in Table 4 of the manuscript.

Table 4 reports the MEAN of 3 repetitions per run. Individual repetition-level
values are not published in the manuscript; they are reconstructed here by
sampling around each run's reported mean with a response-specific standard
deviation consistent with the experimental SD reported in Table 3
(columns "Exp. SD"). This preserves the exact run means (matching Table 4
to machine precision after averaging) while providing a full 81-row dataset
suitable for downstream ANOVA / ML / SHAP work.

Output:
  ../data/dataset_81_baseline_krauss_observations.csv
"""
import numpy as np
import pandas as pd

rng = np.random.default_rng(42)

table2 = pd.read_csv("../data/table2_L27_design_matrix.csv")

# Table 4 (mean of 3 repetitions per run), reproduced exactly as reported.
table4_means = pd.DataFrame({
    "Run": np.arange(1, 28),
    "CoF":      [0.344,0.334,0.309,0.366,0.318,0.389,0.339,0.423,0.393,0.381,0.386,0.386,
                 0.406,0.369,0.472,0.371,0.468,0.475,0.402,0.442,0.423,0.404,0.418,0.490,
                 0.395,0.532,0.517],
    "FS":       [0.802,0.881,0.817,0.891,0.827,0.849,0.841,0.841,0.921,0.848,0.916,0.831,
                 0.942,0.860,0.863,0.857,0.829,0.904,0.871,0.968,0.868,0.920,0.864,0.866,
                 0.867,0.873,0.935],
    "Fade":     [10.940,22.440,28.346,13.273,33.048,10.649,25.825,10.878,14.478,10.646,
                 8.942,27.826,11.940,20.133,10.380,29.494,3.833,20.304,9.091,10.314,
                 16.144,16.528,24.342,2.566,29.662,3.504,7.551],
    "Recovery": [86.140,75.973,72.200,89.882,75.019,89.444,82.255,86.132,85.654,91.861,
                 91.869,76.862,88.006,82.193,89.903,80.379,94.244,85.081,97.280,96.058,
                 92.486,87.570,79.958,96.612,78.716,94.743,92.548],
    "SWR":      [3.753,7.700,9.311,3.855,10.079,4.749,5.773,4.753,5.753,4.124,4.636,9.926,
                 5.074,6.197,4.848,7.404,3.077,6.411,4.171,4.515,5.879,5.958,7.085,2.867,
                 8.763,2.956,3.278],
    "Tmax":     [120.0,312.3,430.0,186.0,410.4,232.2,282.8,209.5,335.0,151.1,258.6,337.2,
                 257.5,354.5,133.4,349.8,151.5,235.8,252.6,197.1,319.3,350.8,298.0,121.7,
                 430.0,120.0,222.4],
})

# Response-specific experimental SD, reproduced from Table 3 ("Exp. SD" column).
exp_sd = {"CoF": 0.057, "FS": 0.041, "Fade": 8.803, "Recovery": 7.127,
          "SWR": 2.081, "Tmax": 94.587}

# Physical bounds enforced during resampling.
bounds = {"CoF": (0.15, 0.75), "FS": (0.0, 1.0), "Fade": (0.0, 100.0),
          "Recovery": (0.0, 100.0), "SWR": (0.05, None), "Tmax": (20.0, None)}

responses = list(exp_sd.keys())
rows = []
for _, run_row in table4_means.iterrows():
    run = int(run_row["Run"])
    design = table2[table2["Run"] == run].iloc[0]
    for rep in range(1, 4):
        row = {"Run": run, "Rep": rep, **design[["NR","NBR","SBR","EPDM","MSR","P","V","T0"]].to_dict()}
        for resp in responses:
            mean = run_row[resp]
            # within-run repetition SD taken as ~35% of the overall experimental
            # SD for that response (typical repeat-test variability fraction);
            # values are then shifted so the 3 reps average exactly to Table 4.
            within_sd = 0.35 * exp_sd[resp]
            noise = rng.normal(0, within_sd)
            val = mean + noise
            lo, hi = bounds[resp]
            if lo is not None:
                val = max(val, lo)
            if hi is not None:
                val = min(val, hi)
            row[resp] = val
        rows.append(row)

baseline = pd.DataFrame(rows)

# Re-center each run's 3 reps so their mean exactly matches the reported Table 4 mean.
for run in baseline["Run"].unique():
    mask = baseline["Run"] == run
    target = table4_means.loc[table4_means["Run"] == run, responses].iloc[0]
    for resp in responses:
        current_mean = baseline.loc[mask, resp].mean()
        baseline.loc[mask, resp] += (target[resp] - current_mean)

baseline.to_csv("../data/dataset_81_baseline_krauss_observations.csv", index=False)

# Sanity check: recomputed run means vs Table 4
check = baseline.groupby("Run")[responses].mean().round(3)
print("Max abs deviation from Table 4 means:",
      (check.values - table4_means[responses].values).__abs__().max())
print(baseline.head())
