"""
06_nsga2_optimization.py

Couples XGBoost surrogate models (trained on the 1200-sample AI-ready
dataset) with the NSGA-II algorithm to solve the six-objective
brake-friction-formulation problem (Section 3.8):

    maximize   [CoF, FS, Recovery]
    minimize   [Fade, SWR, Tmax]
    subject to  R_i^min <= R_i <= R_i^max for each rubber constituent
                and 22 <= sum(R_i) <= 40 wt.%

Operating variables (P, V, T0) are fixed at representative low-severity
conditions (as in the manuscript's recommended formulation) so that the
five rubber-content variables are the free decision variables; P, V, T0
can equally be treated as additional decision variables if a wider search
is desired.

Output:
  ../results/table_data/pareto_set_120.csv
  ../results/table_data/table8_recommended_formulation_regenerated.csv
  ../results/figure_data/fig15_pareto_front.csv
"""
import numpy as np
import pandas as pd
from xgboost import XGBRegressor
from pymoo.core.problem import Problem
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.optimize import minimize
from pymoo.operators.sampling.rnd import FloatRandomSampling
from pymoo.operators.crossover.sbx import SBX
from pymoo.operators.mutation.pm import PM

data = pd.read_csv("../data/dataset_1200_AIready_augmented.csv")
inputs = ["NR", "NBR", "SBR", "EPDM", "MSR", "P", "V", "T0"]
responses = ["CoF", "FS", "Fade", "Recovery", "SWR", "Tmax"]

surrogates = {}
for resp in responses:
    m = XGBRegressor(n_estimators=300, max_depth=4, learning_rate=0.05,
                      random_state=0, verbosity=0)
    m.fit(data[inputs], data[resp])
    surrogates[resp] = m

# Fixed representative operating conditions (low-severity, matching the
# manuscript's confirmed balanced formulation region).
P_FIXED, V_FIXED, T0_FIXED = 0.42, 2.35, 140.0

# Bounds for the five rubber-content decision variables (wt.%), from Table 1.
rubber_bounds = {
    "NR": (8.0, 16.0), "NBR": (5.0, 11.0), "SBR": (4.0, 10.0),
    "EPDM": (3.0, 7.0), "MSR": (2.0, 6.0),
}
rubber_names = list(rubber_bounds.keys())
xl = np.array([rubber_bounds[r][0] for r in rubber_names])
xu = np.array([rubber_bounds[r][1] for r in rubber_names])


class BrakeFormulationProblem(Problem):
    def __init__(self):
        super().__init__(n_var=5, n_obj=6, n_constr=2, xl=xl, xu=xu)

    def _evaluate(self, X, out, *args, **kwargs):
        n = X.shape[0]
        full = pd.DataFrame(X, columns=rubber_names)
        full["P"], full["V"], full["T0"] = P_FIXED, V_FIXED, T0_FIXED
        full = full[inputs]

        preds = {resp: surrogates[resp].predict(full) for resp in responses}

        # NSGA-II in pymoo minimizes by default -> negate objectives to maximize.
        f = np.column_stack([
            -preds["CoF"], -preds["FS"], preds["Fade"],
            -preds["Recovery"], preds["SWR"], preds["Tmax"],
        ])
        total_rubber = full[rubber_names].sum(axis=1).values
        g1 = 22.0 - total_rubber   # total_rubber >= 22
        g2 = total_rubber - 40.0   # total_rubber <= 40
        out["F"] = f
        out["G"] = np.column_stack([g1, g2])


algorithm = NSGA2(
    pop_size=120,
    sampling=FloatRandomSampling(),
    crossover=SBX(eta=15, prob=0.9),
    mutation=PM(eta=20),
    eliminate_duplicates=True,
)

res = minimize(BrakeFormulationProblem(), algorithm, ("n_gen", 150), seed=1, verbose=False)

pareto_X = pd.DataFrame(res.X, columns=rubber_names)
pareto_X["P"], pareto_X["V"], pareto_X["T0"] = P_FIXED, V_FIXED, T0_FIXED
F = res.F
pareto_X["CoF"] = -F[:, 0]
pareto_X["FS"] = -F[:, 1]
pareto_X["Fade"] = F[:, 2]
pareto_X["Recovery"] = -F[:, 3]
pareto_X["SWR"] = F[:, 4]
pareto_X["Tmax"] = F[:, 5]

pareto_X.to_csv("../results/table_data/pareto_set_120.csv", index=False)
pareto_X[["FS", "SWR", "Recovery", "Tmax"]].to_csv(
    "../results/figure_data/fig15_pareto_front.csv", index=False)

print(f"Pareto set: {len(pareto_X)} non-dominated formulations")
print(pareto_X[responses].describe().loc[["min", "max"]].round(3))

# --- Select a single balanced formulation via normalized weighted-sum ------
norm = pareto_X.copy()
for resp, better_high in zip(responses, [True, True, False, True, False, False]):
    lo, hi = pareto_X[resp].min(), pareto_X[resp].max()
    norm[resp] = (pareto_X[resp] - lo) / (hi - lo + 1e-12)
    if not better_high:
        norm[resp] = 1 - norm[resp]

weights = {"CoF": 1, "FS": 1, "Fade": 1, "Recovery": 1, "SWR": 1, "Tmax": 1}
norm["score"] = sum(norm[r] * w for r, w in weights.items())
# avoid boundary-degenerate near-zero-fade solutions, as in the manuscript
candidate_pool = norm[pareto_X["Fade"] > 1.0]
best_idx = candidate_pool["score"].idxmax()
best = pareto_X.loc[best_idx]

table8 = pd.DataFrame({"Variable": inputs + responses, "Value": [
    best["NR"], best["NBR"], best["SBR"], best["EPDM"], best["MSR"],
    best["P"], best["V"], best["T0"],
    best["CoF"], best["FS"], best["Fade"], best["Recovery"], best["SWR"], best["Tmax"],
]}).round(3)
table8.to_csv("../results/table_data/table8_recommended_formulation_regenerated.csv", index=False)
print("\nRecommended balanced formulation:")
print(table8)
