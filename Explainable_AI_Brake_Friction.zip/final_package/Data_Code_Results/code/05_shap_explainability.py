"""
05_shap_explainability.py

Trains an XGBoost surrogate model for each response on the 1200-sample
AI-ready dataset and computes SHAP (SHapley Additive exPlanations) global
feature importance (mean |SHAP value|), reproducing the structure of
Table 7 and the data underlying Figures 12-14.

Output:
  ../results/table_data/table7_shap_importance_regenerated.csv
  ../results/figure_data/fig12_shap_global_importance.csv
  ../results/figure_data/fig13_shap_dependence_NR_CoF.csv
  ../results/figure_data/fig13_shap_dependence_NBR_SWR.csv
  ../results/figure_data/fig14_shap_interaction_CoF.csv
"""
import numpy as np
import pandas as pd
import shap
from xgboost import XGBRegressor

data = pd.read_csv("../data/dataset_1200_AIready_augmented.csv")
inputs = ["NR", "NBR", "SBR", "EPDM", "MSR", "P", "V", "T0"]
responses = ["CoF", "FS", "Fade", "Recovery", "SWR", "Tmax"]

importance_table = {}
shap_values_store = {}

for resp in responses:
    X = data[inputs]
    y = data[resp].values
    model = XGBRegressor(n_estimators=300, max_depth=4, learning_rate=0.05,
                          random_state=0, verbosity=0)
    model.fit(X, y)

    explainer = shap.TreeExplainer(model)
    sv = explainer.shap_values(X)
    shap_values_store[resp] = sv
    importance_table[resp] = np.abs(sv).mean(axis=0)

table7 = pd.DataFrame(importance_table, index=inputs).round(3)
table7.index.name = "Factor"
table7.to_csv("../results/table_data/table7_shap_importance_regenerated.csv")
table7.to_csv("../results/figure_data/fig12_shap_global_importance.csv")
print(table7)

# --- Figure 13: SHAP dependence plots (NR->CoF, NBR->SWR, colour = T0) ----
i_nr, i_t0 = inputs.index("NR"), inputs.index("T0")
dep_nr_cof = pd.DataFrame({
    "NR": data["NR"], "SHAP_value_CoF": shap_values_store["CoF"][:, i_nr], "T0": data["T0"],
})
dep_nr_cof.to_csv("../results/figure_data/fig13_shap_dependence_NR_CoF.csv", index=False)

i_nbr = inputs.index("NBR")
dep_nbr_swr = pd.DataFrame({
    "NBR": data["NBR"], "SHAP_value_SWR": shap_values_store["SWR"][:, i_nbr], "T0": data["T0"],
})
dep_nbr_swr.to_csv("../results/figure_data/fig13_shap_dependence_NBR_SWR.csv", index=False)

# --- Figure 14: pairwise SHAP interaction map for CoF ----------------------
X_cof = data[inputs]
model_cof = XGBRegressor(n_estimators=300, max_depth=4, learning_rate=0.05,
                          random_state=0, verbosity=0).fit(X_cof, data["CoF"])
explainer_cof = shap.TreeExplainer(model_cof)
interaction_vals = explainer_cof.shap_interaction_values(X_cof)
mean_abs_interaction = np.abs(interaction_vals).mean(axis=0)
interaction_df = pd.DataFrame(mean_abs_interaction, index=inputs, columns=inputs).round(4)
interaction_df.to_csv("../results/figure_data/fig14_shap_interaction_CoF.csv")
print("\nTop CoF interactions:")
iu = np.triu_indices(len(inputs), k=1)
pairs = sorted(zip(mean_abs_interaction[iu], [(inputs[a], inputs[b]) for a, b in zip(*iu)]),
               reverse=True)[:5]
for val, (a, b) in pairs:
    print(f"  {a} x {b}: {val:.4f}")
