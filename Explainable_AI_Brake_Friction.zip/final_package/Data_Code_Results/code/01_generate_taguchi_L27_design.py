"""
01_generate_taguchi_L27_design.py

Reconstructs the L27(3^13) Taguchi orthogonal-array design used in the study
(Table 1: factor levels; Table 2: complete 27-run design matrix).

Eight factors are assigned to the L27(3^13) array:
  A = NR (wt.%), B = NBR (wt.%), C = SBR (wt.%), D = EPDM (wt.%), E = MSR (wt.%)
  F = Braking pressure P (MPa), G = Sliding speed V (m/s), H = Initial temperature T0 (degC)

Output:
  ../data/table1_factors_levels.csv
  ../data/table2_L27_design_matrix.csv
"""
import numpy as np
import pandas as pd

# --- Factor levels (Table 1) ---------------------------------------------
factors = {
    "NR":  [8.0, 12.0, 16.0],     # wt.%
    "NBR": [5.0, 8.0, 11.0],      # wt.%
    "SBR": [4.0, 7.0, 10.0],      # wt.%
    "EPDM": [3.0, 5.0, 7.0],      # wt.%
    "MSR": [2.0, 4.0, 6.0],       # wt.%
    "P":   [0.4, 0.8, 1.2],       # MPa
    "V":   [2.0, 5.0, 8.0],       # m/s
    "T0":  [100.0, 200.0, 300.0], # degC
}

table1 = pd.DataFrame({
    "Factor": list(factors.keys()),
    "Level_1_low": [v[0] for v in factors.values()],
    "Level_2_medium": [v[1] for v in factors.values()],
    "Level_3_high": [v[2] for v in factors.values()],
})
table1.to_csv("../data/table1_factors_levels.csv", index=False)

# --- L27 design matrix (Table 2), reproduced exactly as reported ---------
# Level indices (0,1,2) per run for the 8 assigned columns, matching the
# manuscript's Table 2 physical-unit values.
level_idx = np.array([
    [0,0,0,0,0,0,0,0],
    [0,0,1,0,0,1,2,1],
    [0,0,2,0,0,2,1,2],
    [0,1,0,1,2,0,0,1],
    [0,1,1,1,2,1,2,2],
    [0,1,2,1,2,2,1,0],
    [0,2,0,2,1,0,0,2],
    [0,2,1,2,1,1,2,0],
    [0,2,2,2,1,2,1,1],
    [1,0,0,1,1,1,1,0],
    [1,0,1,1,1,2,0,1],
    [1,0,2,1,1,0,2,2],
    [1,1,0,2,0,1,1,1],
    [1,1,1,2,0,2,0,2],
    [1,1,2,2,0,0,2,0],
    [1,2,0,0,2,1,1,2],
    [1,2,1,0,2,2,0,0],
    [1,2,2,0,2,0,2,1],
    [2,0,0,2,2,2,2,0],
    [2,0,1,2,2,0,1,1],
    [2,0,2,2,2,1,0,2],
    [2,1,0,0,1,2,2,1],
    [2,1,1,0,1,0,1,2],
    [2,1,2,0,1,1,0,0],
    [2,2,0,1,0,2,2,2],
    [2,2,1,1,0,0,1,0],
    [2,2,2,1,0,1,0,1],
])

cols = ["NR", "NBR", "SBR", "EPDM", "MSR", "P", "V", "T0"]
data = {}
for j, c in enumerate(cols):
    lv = factors[c]
    data[c] = [lv[i] for i in level_idx[:, j]]

table2 = pd.DataFrame(data)
table2.insert(0, "Run", np.arange(1, 28))
table2.to_csv("../data/table2_L27_design_matrix.csv", index=False)

print("Wrote table1_factors_levels.csv and table2_L27_design_matrix.csv")
print(table2.head())
