"""
04_ml_model_comparison.py

Trains and compares six regression algorithms (linear regression, random
forest, support vector regression, gradient boosting, XGBoost, and a
feed-forward ANN) for each of the six responses, on an 80/20 train/test
split of the 1200-sample AI-ready dataset (Section 3.7, Table 6).

Output:
  ../results/table_data/table6_ml_model_comparison_regenerated.csv
  ../results/figure_data/fig10_predicted_vs_measured_CoF.csv
  ../results/figure_data/fig11_predicted_vs_measured_SWR.csv
"""
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.svm import SVR
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from xgboost import XGBRegressor

rng_seed = 0
data = pd.read_csv("../data/dataset_1200_AIready_augmented.csv")
inputs = ["NR", "NBR", "SBR", "EPDM", "MSR", "P", "V", "T0"]
responses = ["CoF", "FS", "Fade", "Recovery", "SWR", "Tmax"]

def mape(y_true, y_pred):
    y_true = np.asarray(y_true)
    mask = np.abs(y_true) > 1e-6
    return float(np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100)

def make_models():
    return {
        "Linear Regression": LinearRegression(),
        "Random Forest": RandomForestRegressor(n_estimators=300, random_state=rng_seed),
        "Support Vector Regression": SVR(kernel="rbf", C=10, epsilon=0.01),
        "Gradient Boosting": GradientBoostingRegressor(random_state=rng_seed),
        "XGBoost": XGBRegressor(n_estimators=300, max_depth=4, learning_rate=0.05,
                                 random_state=rng_seed, verbosity=0),
        "ANN (MLP)": MLPRegressor(hidden_layer_sizes=(64, 32), activation="relu",
                                   max_iter=3000, random_state=rng_seed),
    }

X = data[inputs].values
results = []
predictions_for_figures = {}

for resp in responses:
    y = data[resp].values
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=rng_seed)

    scaler = StandardScaler().fit(X_train)
    X_train_s, X_test_s = scaler.transform(X_train), scaler.transform(X_test)

    best_r2 = -np.inf
    for name, model in make_models().items():
        needs_scaling = name in ("Linear Regression", "Support Vector Regression", "ANN (MLP)")
        xtr, xte = (X_train_s, X_test_s) if needs_scaling else (X_train, X_test)
        model.fit(xtr, y_train)
        y_pred = model.predict(xte)

        r2 = r2_score(y_test, y_pred)
        rmse = float(np.sqrt(mean_squared_error(y_test, y_pred)))
        mae = mean_absolute_error(y_test, y_pred)
        m = mape(y_test, y_pred)
        results.append({"Response": resp, "Model": name, "R2": round(r2, 3),
                         "RMSE": round(rmse, 3), "MAE": round(mae, 3), "MAPE": round(m, 3)})

        if resp in ("CoF", "SWR") and r2 > best_r2:
            best_r2 = r2
            predictions_for_figures[resp] = (y_test.copy(), y_pred.copy(), name, r2)

table6 = pd.DataFrame(results)
table6.to_csv("../results/table_data/table6_ml_model_comparison_regenerated.csv", index=False)
print(table6.groupby("Model")["R2"].mean().sort_values(ascending=False))

for resp in ("CoF", "SWR"):
    y_test, y_pred, best_name, r2 = predictions_for_figures[resp]
    fig_df = pd.DataFrame({"Measured": y_test, "Predicted": y_pred})
    fname = f"../results/figure_data/fig{'10' if resp=='CoF' else '11'}_predicted_vs_measured_{resp}.csv"
    fig_df.to_csv(fname, index=False)
    print(f"Best model for {resp}: {best_name} (R2={r2:.3f}) -> {fname}")
