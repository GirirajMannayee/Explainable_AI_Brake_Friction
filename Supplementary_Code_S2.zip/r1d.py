from common import *
import warnings;warnings.filterwarnings("ignore")
from scipy.stats import spearmanr,ks_2samp
from sklearn.ensemble import RandomForestRegressor
exec(open("r1c.py").read().split("T=pd.DataFrame")[0].split("def tests")[0].replace("B=D[D.Source","B_=D[D.Source"))  # imports only
Bb=pd.read_csv("dataset_81_baseline_krauss_observations.csv");lo=Bb[INP].min().values;hi=Bb[INP].max().values
nf=dict(CoF=.03,FS=.02,Fade=.05,Recovery=.02,SWR=.05,Tmax=.03)
print("baseline run-mean dT min:",(Bb.groupby("Run").Tmax.mean()-Bb.groupby("Run").T0.first()).min().round(1),"| runs with mean dT<=0:",int(((Bb.groupby("Run").Tmax.mean()-Bb.groupby("Run").T0.first())<=0).sum()))
def gen(v2,seed=7,n=2200):
    rng=np.random.default_rng(seed);c=pd.DataFrame({v:rng.uniform(lo[i],hi[i],n) for i,v in enumerate(INP)})
    for r in RESP:
        if v2 and r=="Tmax":
            y=(Bb.Tmax-Bb.T0).values;m=RandomForestRegressor(n_estimators=300,min_samples_leaf=2,random_state=0).fit(Bb[INP].values,y)
            c["Tmax"]=c.T0+m.predict(c[INP].values)+rng.normal(0,nf[r]*y.std(),n)
        else:
            m=RandomForestRegressor(n_estimators=300,min_samples_leaf=2,random_state=0).fit(Bb[INP].values,Bb[r].values)
            c[r]=m.predict(c[INP].values)+rng.normal(0,nf[r]*Bb[r].std(),n)
    t=c[INP[:5]].sum(1);ok=(t>=22)&(t<=40)&(c.SWR>0)&(c.Fade>=0)&(c.Fade<=100)&(c.Recovery>=0)&(c.Recovery<=100)&(c.CoF>=.25)&(c.CoF<=.6)
    if v2:ok&=(c.Tmax>=c.T0)
    return c[ok].sample(n=1119,random_state=1).reset_index(drop=True),ok.sum()
rows=[]
for name,v2 in [("v1 (as used)",False),("v2 (dT model + Tmax>=T0)",True)]:
    S,k=gen(v2);dT=S.Tmax-S.T0;q=S.CoF*S.P*S.V;m=dT>0
    rows.append({"Generator":name,"retained of 2200":k,"dT<=0 (%)":(dT<=0).mean()*100,"rho(dT, mu*P*V)":spearmanr(dT,q)[0],"exponent n":np.polyfit(np.log(q[m]),np.log(dT[m]),1)[0],"Tmax SD ratio":S.Tmax.std()/Bb.Tmax.std(),"KS p Tmax":ks_2samp(Bb.Tmax,S.Tmax).pvalue,"rho(Fade,Tmax)":spearmanr(S.Fade,S.Tmax)[0],"rho(SWR,Tmax)":spearmanr(S.SWR,S.Tmax)[0]})
    S.to_csv(f"out/synth_{'v2' if v2 else 'v1'}.csv",index=False)
R=pd.DataFrame(rows);pd.set_option("display.width",220);print(R.round(3).T.to_string());R.to_csv("out/generator_v1_v2.csv",index=False)
