from common import *
import warnings;warnings.filterwarnings("ignore")
import shap
from sklearn.ensemble import RandomForestRegressor,GradientBoostingRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.compose import TransformedTargetRegressor as TT
from sklearn.model_selection import KFold
from xgboost import XGBRegressor
Bb=pd.read_csv("dataset_81_baseline_krauss_observations.csv")
V2=pd.concat([Bb[INP+RESP],pd.read_csv("out/synth_v2.csv")[INP+RESP]],ignore_index=True);V1=D[INP+RESP]
def ann():return TT(make_pipeline(StandardScaler(),MLPRegressor(hidden_layer_sizes=(64,),alpha=1,activation="tanh",early_stopping=True,n_iter_no_change=20,max_iter=500,random_state=0)),transformer=StandardScaler())
M={"Gradient Boosting":lambda:GradientBoostingRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0),"Random Forest":lambda:RandomForestRegressor(150,random_state=0),"XGBoost":lambda:XGBRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0,verbosity=0),"ANN":ann}
res=[]
for nm,df in [("v1 (as used)",V1),("v2 (physics-informed)",V2)]:
    Xk=df[INP].values;kf=list(KFold(5,shuffle=True,random_state=0).split(Xk))
    for mn,mk in M.items():
        r2=[]
        for r in RESP:
            y=df[r].values;P=np.zeros(len(y))
            for a,b in kf:P[b]=mk().fit(Xk[a],y[a]).predict(Xk[b])
            r2.append(1-((y-P)**2).sum()/((y-y.mean())**2).sum())
        res.append(dict(Dataset=nm,Model=mn,meanR2=np.mean(r2)))
    for resp in ["CoF","SWR","Tmax"]:
        m=XGBRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0,verbosity=0).fit(df[INP],df[resp]);sv=np.abs(shap.TreeExplainer(m).shap_values(df[INP])).mean(0)
        print(nm,resp,"SHAP top5:",list(pd.Series(sv,INP).sort_values(ascending=False).index[:5]))
R=pd.DataFrame(res);print(R.round(3).to_string());R.to_csv("out/model_rank_v2.csv",index=False)
runs=(Bb.groupby("Run").Tmax.mean()-Bb.groupby("Run").T0.first());print("runs with mean dT<=0:",{int(k):round(v,1) for k,v in runs[runs<=0].items()})
