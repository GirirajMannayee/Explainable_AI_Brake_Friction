from common import *
import time
from xgboost import XGBRegressor
from pymoo.core.problem import Problem
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.optimize import minimize
from pymoo.operators.crossover.sbx import SBX
from pymoo.operators.mutation.pm import PM
from pymoo.operators.sampling.rnd import FloatRandomSampling
from pymoo.core.callback import Callback
from pymoo.indicators.igd_plus import IGDPlus
from pymoo.util.nds.non_dominated_sorting import NonDominatedSorting
sur={r:XGBRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0,verbosity=0).fit(D[INP],D[r]) for r in RESP}
xl=np.array([8,5,4,3,2,.4,2,100.]);xu=np.array([16,11,10,7,6,1.2,8,300.])
class Pb(Problem):
    def __init__(s):super().__init__(n_var=8,n_obj=6,n_constr=2,xl=xl,xu=xu)
    def _evaluate(s,x,out,*a,**k):
        d=pd.DataFrame(x,columns=INP);p={r:sur[r].predict(d) for r in RESP}
        out["F"]=np.column_stack([-p["CoF"],-p["FS"],p["Fade"],-p["Recovery"],p["SWR"],p["Tmax"]])
        t=x[:,:5].sum(1);out["G"]=np.column_stack([22-t,t-40])
# normalisation box from sampled feasible space (fixed for all runs)
rs=np.random.default_rng(0);Xs=rs.uniform(xl,xu,(20000,8));Xs=Xs[(Xs[:,:5].sum(1)>=22)&(Xs[:,:5].sum(1)<=40)]
o=Pb();Fo={};
o_out={};o._evaluate(Xs,o_out);FS=o_out["F"];lo,hi=FS.min(0),FS.max(0);REF=np.ones(6)*1.1
MC=np.random.default_rng(1).uniform(0,1.1,(150000,6))
def hv(F):
    N=(F-lo)/(hi-lo);dom=np.zeros(len(MC),bool)
    for f in N:
        dom|=np.all(MC>=f,axis=1)
    return dom.mean()*1.1**6
class CB(Callback):
    def __init__(s,every=5):super().__init__();s.every=every;s.rec=[]
    def notify(s,alg):
        g=alg.n_gen
        if g%s.every==0:
            F=alg.opt.get("F");s.rec.append(dict(gen=g,HV=hv(F),n_nd=len(F),**{f"m_{r}":v for r,v in zip(RESP,np.where(np.array([-1,-1,1,-1,1,1])<0,-F.mean(0),F.mean(0)))}))
            s.F=F
def run(seed,ngen,pop=120,every=5):
    cb=CB(every);alg=NSGA2(pop_size=pop,sampling=FloatRandomSampling(),crossover=SBX(eta=15,prob=.9),mutation=PM(eta=20),eliminate_duplicates=True)
    r=minimize(Pb(),alg,("n_gen",ngen),seed=seed,callback=cb,verbose=False);return r,pd.DataFrame(cb.rec)
import sys,os
st=sys.argv[1];t=time.time()
if st=="ref":
    r0,tr0=run(1,500);tr0.to_csv("out/nsga_trace_seed1.csv",index=False);np.save("out/ref_front.npy",r0.F)
    r1,_=run(1,150);F=r1.F;pf=pd.DataFrame(r1.X,columns=INP)
    for n,v in zip(RESP,[-F[:,0],-F[:,1],F[:,2],-F[:,3],F[:,4],F[:,5]]):pf[n]=v
    pf.to_csv("out/pareto_150gen_8var.csv",index=False);print(pf[RESP].agg(["min","max"]).round(3))
if st=="seeds":
    REFF=np.load("out/ref_front.npy");fin=[];traces=[]
    for s in range(int(sys.argv[2]),int(sys.argv[3])):
        r,tr=run(100+s,150);tr["seed"]=s;traces.append(tr);fin.append(dict(seed=s,HV150=hv(r.F),IGDp_to_ref=IGDPlus(REFF)(r.F),n=len(r.F)))
    pd.concat(traces).to_csv(f"out/nsga_traces_{sys.argv[2]}.csv",index=False);pd.DataFrame(fin).to_csv(f"out/nsga_final_{sys.argv[2]}.csv",index=False)
if st=="sens":
    REFF=np.load("out/ref_front.npy");sens=[]
    for pop,ng in [(60,150),(120,50),(120,150),(120,300),(240,150)]:
        if 1:
            for s in range(3):
                r,_=run(200+s,ng,pop,10**6);sens.append(dict(pop=pop,gen=ng,seed=s,HV=hv(r.F),IGDp=IGDPlus(REFF)(r.F)))
    pd.DataFrame(sens).to_csv("out/nsga_sensitivity.csv",index=False)
print(st,round(time.time()-t))
