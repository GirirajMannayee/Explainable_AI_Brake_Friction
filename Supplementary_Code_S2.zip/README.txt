Supplementary Code S2 - analyses added during the revision
Place the released data files (dataset_1200_AIready_augmented.csv, dataset_81_baseline_krauss_observations.csv,
table2_L27_design_matrix.csv) in the working directory, create an out/ folder, and run from that directory.
Environment used: Python 3.12.3, NumPy 2.4.4, pandas 3.0.2, scikit-learn 1.8.0, SciPy 1.17.1, XGBoost, SHAP, pymoo, statsmodels.
common.py   data loading and metrics (R2, RMSE, MAE, MAPE)
nnlib.py    NumPy MLP with dropout, L2, Adam, early stopping
ablate.py   ANN one-factor-at-a-time ablation (KFold 5, random_state 0)            -> Table 6b
cvbench.py  repeated 5x3 CV ("default") and nested 5-fold CV ("tuned")  [arg: default|tuned] -> Table 6
shap_int.py SHAP interaction values vs ANOVA with interaction terms                   -> Tables 7b, 7c
nsga_conv.py NSGA-II convergence [arg: ref | seeds a b | sens]; seeds 1, 100-109, 200-202 -> Table 10
q6to11.py, q10.py  domain, extrapolation test, formulation-condition coupling         -> Tables 1b, 12, 13
r2a.py, r2b.py     sampler comparison (KS/SD), model ranking, leave-one-design-point-out -> Table 3b
r2c.py      weight sensitivity of the compromise solution, over-40 wt.% check          -> Table 14
r1a.py      grouped leakage-free evaluation (GroupKFold 9; synthetic regenerated)      -> Table 6c
r1b.py      constraint-violation sensitivity; generator polynomial coefficients        -> Tables 3d, S1
r1c.py, r1f.py physical-consistency tests; r1d.py, r1e.py physics-informed generator v2 -> Tables 15-17
figs.py     figures and CV tables
r6a.py      grouped leakage-free validation (generator calibrated on training runs; 3 random groupings), original vs generated test sets -> Table 6c
r5a.py      alternative L27 column assignment search; solubility-parameter mismatch index   -> Tables 2g, 2h
r4a.py      L27 aliasing (GF(3)), pure-error vs lack-of-fit ANOVA, S/N ratios (all responses) -> Tables 2e, 2f, 5c, 5e
r4b.py      ANOVA tables 5a/5b and regenerated Figures 7 and 8
r3a.py, r3b.py admissible (<= 40 wt.%) data set: ANOVA, CV, SHAP, NSGA-II                 -> Table 19
r3c.py      label-permutation control for SHAP vs ANOVA; total-rubber vs blend importance -> Tables 18, 20
