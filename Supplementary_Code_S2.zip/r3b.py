src=open("nsga_conv.py").read().split("import sys,os")[0];exec(src)
import shap
from sklearn.model_selection import KFold
from sklearn.ensemble import RandomForestRegressor,GradientBoostingRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.compose import TransformedTargetRegressor as TT
from scipy.stats import spearmanr
Dc=pd.read_csv("out/dataset_admissible_1200.csv");D0=D[INP+RESP]
def ann():return TT(make_pipeline(StandardScaler(),MLPRegressor(hidden_layer_sizes=(64,),alpha=1,activation="tanh",early_stopping=True,n_iter_no_change=20,max_iter=500,random_state=0)),transformer=StandardScaler())
M={"Gradient Boosting":lambda:GradientBoostingRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0),"Random Forest":lambda:RandomForestRegressor(150,random_state=0),"XGBoost":lambda:XGBRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0,verbosity=0),"ANN":ann}
res=[]
for nm,df in [("Full (as used)",D0),("Admissible (<= 40 wt.%)",Dc)]:
    Xk=df[INP].values;kf=list(KFold(5,shuffle=True,random_state=0).split(Xk))
    for mn,mk in M.items():
        r2=[]
        for r in RESP:
            y=df[r].values;P=np.zeros(len(y))
            for a,b in kf:P[b]=mk().fit(Xk[a],y[a]).predict(Xk[b])
            r2.append(1-((y-P)**2).sum()/((y-y.mean())**2).sum())
        res.append(dict(Dataset=nm,Model=mn,meanR2=np.mean(r2)))
    for resp in RESP:
        m=XGBRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0,verbosity=0).fit(df[INP],df[resp]);sv=np.abs(shap.TreeExplainer(m).shap_values(df[INP])).mean(0)
        res.append(dict(Dataset=nm,Model="SHAP "+resp,meanR2=np.nan,top5=", ".join(pd.Series(sv,INP).sort_values(ascending=False).index[:5])))
R=pd.DataFrame(res);R.to_csv("out/admissible_models_shap.csv",index=False);pd.set_option("display.width",200);print(R.to_string())
# NSGA-II equal-weight solution on the admissible surrogate vs full
OBJ=["CoF","FS","Fade","Recovery","SWR","Tmax"];HIGH=[True,True,False,True,False,False]
def front(seed,ng,pop):
    r,_=run(seed,ng,pop,10**6);pf=pd.DataFrame(r.X,columns=INP);F=r.F
    for n,v in zip(OBJ,[-F[:,0],-F[:,1],F[:,2],-F[:,3],F[:,4],F[:,5]]):pf[n]=v
    return pf
def pick(pf):
    N=pd.DataFrame({r:((pf[r]-pf[r].min())/(pf[r].max()-pf[r].min()+1e-12)) if h else 1-((pf[r]-pf[r].min())/(pf[r].max()-pf[r].min()+1e-12)) for r,h in zip(OBJ,HIGH)});s=N.sum(1).where(pf.Fade>1.0,-1e9);return pf.loc[int(s.argmax())]
out=[]
for nm,df in [("Full (as used)",D0),("Admissible (<= 40 wt.%)",Dc)]:
    sur={r:XGBRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0,verbosity=0).fit(df[INP],df[r]) for r in RESP}
    pf=front(1,150,120);b=pick(pf);out.append(dict(Dataset=nm,**{k:b[k] for k in INP+OBJ}))
O=pd.DataFrame(out);O.to_csv("out/admissible_nsga_pick.csv",index=False);print(O.round(3).T.to_string())
