import numpy as np,pandas as pd
RESP=["CoF","FS","Fade","Recovery","SWR","Tmax"]
o=pd.read_csv("out/abl_preds.csv");B=pd.read_csv("dataset_81_baseline_krauss_observations.csv");rg={r:B[r].max()-B[r].min() for r in RESP}
runs=sorted(o.Run.unique());models=list(o.Model.unique());sets=list(o.Setting.unique())
def r2(y,p):return 1-((y-p)**2).sum()/((y-y.mean())**2).sum()
def metrics(d):
    out={}
    for r in RESP:
        y=d[f"y_{r}"].values;p=d[f"p_{r}"].values;out[r]=(r2(y,p),np.sqrt(((y-p)**2).mean())/rg[r]*100)
    return out
rows=[]
for m in models:
    for s in sets:
        d=o[(o.Model==m)&(o.Setting==s)];mt=metrics(d);rows.append(dict(Model=m,Setting=s,meanR2=np.mean([v[0] for v in mt.values()]),NRMSE=np.mean([v[1] for v in mt.values()]),**{f"R2_{r}":mt[r][0] for r in RESP}))
S=pd.DataFrame(rows);S.to_csv("out/abl_summary.csv",index=False)
# paired cluster bootstrap over runs for delta R2 (aug - no aug), identical held-out rows
rng=np.random.default_rng(0);byrun={m:{s:{run:o[(o.Model==m)&(o.Setting==s)&(o.Run==run)] for run in runs} for s in sets} for m in models}
dl=[]
for m in models:
    boots=[]
    for b in range(1000):
        samp=rng.choice(runs,len(runs));vals=[]
        for s in sets:
            d=pd.concat([byrun[m][s][r] for r in samp]);vals.append(np.mean([v[0] for v in metrics(d).values()]))
        boots.append(vals[1]-vals[0])
    base=S[(S.Model==m)];obs=base[base.Setting==sets[1]].meanR2.iloc[0]-base[base.Setting==sets[0]].meanR2.iloc[0]
    dl.append(dict(Model=m,delta_R2=obs,lo=np.percentile(boots,2.5),hi=np.percentile(boots,97.5),frac_boot_pos=np.mean(np.array(boots)>0)))
Dl=pd.DataFrame(dl);Dl.to_csv("out/abl_delta.csv",index=False)
pd.set_option("display.width",220);print(S.round(3).to_string());print(Dl.round(3).to_string())
# response-wise best model per setting
for s in sets:
    t=S[S.Setting==s].set_index("Model")[[f"R2_{r}" for r in RESP]];print(s);print(t.round(3).to_string());print("best per response:",{r:t[f"R2_{r}"].idxmax() for r in RESP})
sel=pd.read_csv("out/abl_sel.csv");print(sel[sel.Model=="ANN (MLP)"].groupby(["Setting","cfg"]).size())
