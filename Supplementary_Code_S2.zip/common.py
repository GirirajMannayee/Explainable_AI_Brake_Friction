import numpy as np, pandas as pd, warnings
warnings.filterwarnings("ignore")
D = pd.read_csv("/home/claude/work/dataset_1200_AIready_augmented.csv")
INP = ["NR","NBR","SBR","EPDM","MSR","P","V","T0"]
RESP = ["CoF","FS","Fade","Recovery","SWR","Tmax"]
X = D[INP].values
def metrics(y, p):
    e = y-p
    rmse = float(np.sqrt(np.mean(e**2))); mae = float(np.mean(np.abs(e)))
    r2 = float(1-np.sum(e**2)/np.sum((y-y.mean())**2))
    m = np.abs(y)>1e-6
    mape = float(np.mean(np.abs(e[m]/y[m]))*100)
    return dict(R2=r2,RMSE=rmse,MAE=mae,MAPE=mape)
