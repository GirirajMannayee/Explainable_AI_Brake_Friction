import itertools as it,numpy as np,pandas as pd,random
pts=sorted({tuple(v) for v in it.product(range(3),repeat=3) if any(v)} and set())
def norm(v):
    v=[x%3 for x in v]
    for x in v:
        if x:
            inv=1 if x==1 else 2;return tuple((y*inv)%3 for y in v)
P=sorted({norm(v) for v in it.product(range(3),repeat=3) if any(v)});assert len(P)==13
F=["NR","NBR","SBR","EPDM","MSR","P","V","T0"]
cur={"NR":(1,0,0),"NBR":(0,1,0),"SBR":(0,0,1),"EPDM":(1,1,0),"MSR":(1,2,0),"P":(1,0,1),"V":(1,0,2),"T0":(0,1,1)}
def comps(a,b):return norm([x+y for x,y in zip(a,b)]),norm([x-y for x,y in zip(a,b)])
key=[("NR","SBR"),("SBR","T0"),("NBR","T0"),("NBR","SBR"),("NR","T0"),("EPDM","T0"),("V","T0"),("EPDM","V")]
def evalA(asg):
    used=set(asg.values());free=[p for p in P if p not in used];res=[]
    for a,b in key:
        c1,c2=comps(asg[a],asg[b]);res.append((a,b,c1 in free and c2 in free,sum(c in free for c in (c1,c2)),(c1,c2)))
    clear=[r for r in res if r[2]];cols=[c for r in clear for c in r[4]];sep=len(set(cols))==len(cols)   # clear interactions use disjoint free columns -> separable
    return res,len(clear),sep,sum(r[3] for r in res)
def score(asg):
    res,nc,sep,nh=evalA(asg);return (nc if sep else nc-0.5*nc,nh)
cur_res,nc,sep,nh=evalA(cur);print("current assignment: clear key interactions",nc,"half-free comps total",nh,[(r[0]+"x"+r[1],r[3]) for r in cur_res])
random.seed(1);best=None;bs=(-1,-1)
for _ in range(400000):
    asg=dict(zip(F,random.sample(P,8)));s=score(asg)
    if s>bs:bs=s;best=asg
res,nc,sep,nh=evalA(best);print("best score",bs);print({k:v for k,v in best.items()});print("clear:",nc,"separable:",sep,"free comps:",nh)
for r in res:print(r[0]+"×"+r[1],"free components:",r[3],"clear" if r[2] else "")
used=set(best.values());free=[p for p in P if p not in used];print("free cols",free)
pd.DataFrame([dict(Factor=k,GF3=str(v)) for k,v in best.items()]).to_csv("out/alt_assignment.csv",index=False)
pd.DataFrame([dict(pair=r[0]+"×"+r[1],free_components=r[3],clear=r[2],cols=str(r[4])) for r in res]).to_csv("out/alt_assignment_keys.csv",index=False)
# how many distinct 'clear and separable' sets can include exactly the top-two physical interactions NR×T0 and NBR×T0 ?
print("\n--- constrained search: NR×T0 and NBR×T0 both clear and separable (disjoint free columns)")
best2=None;b2=-1
random.seed(2)
for _ in range(600000):
    asg=dict(zip(F,random.sample(P,8)));used=set(asg.values());free=[p for p in P if p not in used]
    c1=comps(asg["NR"],asg["T0"]);c2=comps(asg["NBR"],asg["T0"])
    if all(c in free for c in c1+c2) and len(set(c1+c2))==4:
        res,nc,sep,nh=evalA(asg);s=nh
        if s>b2:b2=s;best2=asg
res,nc,sep,nh=evalA(best2);print({k:v for k,v in best2.items()});print("free cols",[p for p in P if p not in set(best2.values())])
for r in res:print(r[0]+"×"+r[1],"free components:",r[3],"CLEAR" if r[2] else "")
# aliasing of main effects in this assignment
al={f:0 for f in F};inv={v:k for k,v in best2.items()}
for a,b in it.combinations(F,2):
    for c in comps(best2[a],best2[b]):
        if c in inv:al[inv[c]]+=1
print("main-effect alias counts:",al)
pd.DataFrame([dict(Factor=k,GF3=str(v)) for k,v in best2.items()]).to_csv("out/alt_assignment2.csv",index=False)
pd.DataFrame([dict(pair=r[0]+"×"+r[1],free_components=r[3],clear=r[2]) for r in res]).to_csv("out/alt_assignment2_keys.csv",index=False)
# mismatch index per L27 run using Hildebrand parameters (midpoints) from the verified table
d=dict(NR=16.4,NBR=19.8,SBR=17.45,EPDM=16.2);t2=pd.read_csv("table2_L27_design_matrix.csv");idx=[]
for r in t2.itertuples():
    w={k:getattr(r,k) for k in d};T=sum(w.values());idx.append(sum(w[a]*w[b]/T**2*abs(d[a]-d[b]) for a,b in it.combinations(d,2)))
t2["mismatch"]=idx;print("mismatch index (MPa^0.5, 4 solubility-parametrised rubbers) min/max:",round(min(idx),2),round(max(idx),2),"| run max",int(t2.loc[t2.mismatch.idxmax(),"Run"]),"run min",int(t2.loc[t2.mismatch.idxmin(),"Run"]))
t2[["Run","mismatch"]].to_csv("out/mismatch_index.csv",index=False)
pm=pd.DataFrame({a:{b:abs(d[a]-d[b]) for b in d} for a in d});print(pm.round(2))
