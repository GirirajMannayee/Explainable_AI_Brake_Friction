import numpy as np
class DropMLP:
    """Numpy MLP: ReLU, inverted dropout, L2, Adam, optional early stopping (validation split)."""
    def __init__(s,hidden=(128,64),dropout=0.0,alpha=1e-4,lr=1e-3,epochs=300,batch=32,es=False,patience=25,seed=0):
        s.h=hidden;s.p=dropout;s.a=alpha;s.lr=lr;s.ep=epochs;s.b=batch;s.es=es;s.pat=patience;s.seed=seed
    def _init(s,d):
        r=np.random.default_rng(s.seed);sz=[d,*s.h,1]
        s.W=[r.normal(0,np.sqrt(2/sz[i]),(sz[i],sz[i+1])) for i in range(len(sz)-1)]
        s.B=[np.zeros(sz[i+1]) for i in range(len(sz)-1)]
    def _fwd(s,x,train,r=None):
        acts=[x];masks=[]
        for i in range(len(s.W)-1):
            z=acts[-1]@s.W[i]+s.B[i];a=np.maximum(z,0)
            if train and s.p>0:
                m=(r.random(a.shape)>s.p)/(1-s.p);a=a*m;masks.append(m)
            else: masks.append(None)
            acts.append(a)
        return acts,masks,acts[-1]@s.W[-1]+s.B[-1]
    def fit(s,x,y):
        r=np.random.default_rng(s.seed);s._init(x.shape[1]);y=y.reshape(-1,1)
        if s.es:
            idx=r.permutation(len(x));nv=int(.15*len(x));vi,ti=idx[:nv],idx[nv:];xv,yv=x[vi],y[vi];x,y=x[ti],y[ti]
        P=[*s.W,*s.B];mo=[np.zeros_like(q) for q in P];ve=[np.zeros_like(q) for q in P];t=0
        best=np.inf;bw=None;bad=0;L=len(s.W)
        for ep in range(s.ep):
            perm=r.permutation(len(x))
            for k in range(0,len(x),s.b):
                bi=perm[k:k+s.b];xb,yb=x[bi],y[bi];acts,masks,out=s._fwd(xb,True,r)
                g=2*(out-yb)/len(xb);gW=[None]*L;gB=[None]*L
                for i in range(L-1,-1,-1):
                    gW[i]=acts[i].T@g+s.a*s.W[i];gB[i]=g.sum(0)
                    if i>0:
                        g=g@s.W[i].T;g=g*(acts[i]>0)
                        if masks[i-1] is not None:g=g*masks[i-1]
                G=[*gW,*gB];t+=1
                for j,(q,gq) in enumerate(zip(P,G)):
                    mo[j]=.9*mo[j]+.1*gq;ve[j]=.999*ve[j]+.001*gq**2
                    q-=s.lr*(mo[j]/(1-.9**t))/(np.sqrt(ve[j]/(1-.999**t))+1e-8)
            if s.es:
                v=np.mean((s._fwd(xv,False)[2]-yv)**2)
                if v<best-1e-6:best=v;bw=([w.copy() for w in s.W],[b.copy() for b in s.B]);bad=0
                else:
                    bad+=1
                    if bad>=s.pat:break
        if s.es and bw:s.W,s.B=bw
        return s
    def predict(s,x):return s._fwd(x,False)[2].ravel()
