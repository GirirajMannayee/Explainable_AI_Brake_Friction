from common import *
import time,json,sys
from nnlib import DropMLP
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import KFold
kf=list(KFold(5,shuffle=True,random_state=0).split(X))
def run(make,ystd=True,label=""):
    rows=[]
    for resp in RESP:
        y=D[resp].values;P=np.zeros(1200)
        for tr,te in kf:
            sc=StandardScaler().fit(X[tr]);ym,ys=(y[tr].mean(),y[tr].std()) if ystd else (0,1)
            m=make();m.fit(sc.transform(X[tr]),(y[tr]-ym)/ys);P[te]=m.predict(sc.transform(X[te]))*ys+ym
        rows.append(dict(Response=resp,**metrics(y,P)))
    df=pd.DataFrame(rows);df.insert(0,"Setting",label);return df
sk=lambda **k:(lambda:MLPRegressor(max_iter=500,random_state=0,**k))
S=[] # (factor, label, maker, ystd)
S+=[("Target scaling","raw y (original)",sk(hidden_layer_sizes=(64,32)),False),("Target scaling","standardised y",sk(hidden_layer_sizes=(64,32)),True)]
for h in [(8,),(16,),(64,),(64,32),(128,64),(128,64,32),(256,128)]:S.append(("Architecture",str(h),sk(hidden_layer_sizes=h),True))
for a in [0,1e-4,1e-3,1e-2,1e-1,1.0]:S.append(("L2 alpha",f"{a:g}",sk(hidden_layer_sizes=(128,64),alpha=a),True))
for es in [False,True]:S.append(("Early stopping","on" if es else "off",sk(hidden_layer_sizes=(128,64),early_stopping=es,n_iter_no_change=20),True))
for lr in [1e-4,1e-3,1e-2]:S.append(("Learning rate",f"{lr:g}",sk(hidden_layer_sizes=(128,64),learning_rate_init=lr),True))
S.append(("Activation","tanh",sk(hidden_layer_sizes=(128,64),activation="tanh"),True))
for p in [0,0.05,0.1,0.2,0.3]:S.append(("Dropout",f"{p:g}",(lambda p=p:DropMLP((128,64),dropout=p,epochs=200)),True))
S.append(("Dropout","0.1 + early stop",(lambda:DropMLP((128,64),dropout=.1,epochs=300,es=True)),True))
import os
allr=[pd.read_csv("out/ann_ablation.csv")] if os.path.exists("out/ann_ablation.csv") else []
done=set(zip(allr[0].Factor,allr[0].Setting)) if allr else set()
T0=time.time()
for f,l,mk,ys in S:
    if (f,l) in done: continue
    if time.time()-T0>230: break
    t=time.time();df=run(mk,ys,l);df.insert(0,"Factor",f);allr.append(df)
    print(f,l,round(df.R2.mean(),3),round(df[df.Response=="CoF"].R2.iloc[0],3),round(time.time()-t),"s",flush=True)
    pd.concat(allr).to_csv("out/ann_ablation.csv",index=False)
