from common import *
import numpy as np,pandas as pd,itertools
from scipy import stats
B=pd.read_csv("dataset_81_baseline_krauss_observations.csv");t2=pd.read_csv("table2_L27_design_matrix.csv")
cols=INP;lv=np.array([[sorted(t2[c].unique()).index(v) for v in t2[c]] for c in cols]).T   # 27 x 8 level indices
# --- GF(3) coordinates of the 27 runs: find (x1,x2,x3) so that each column is a linear form
import itertools as it
# take three independent columns as pseudo-factors: NR, NBR, SBR -> check independence, then express others
base=[0,1,2];X=lv[:,base]
def coef(col):
    for a,b,c in it.product(range(3),repeat=3):
        if ((a*X[:,0]+b*X[:,1]+c*X[:,2])%3==lv[:,col]%3).all():return (a,b,c)
    # allow constant offsets
    for a,b,c,k in it.product(range(3),repeat=4):
        if ((a*X[:,0]+b*X[:,1]+c*X[:,2]+k)%3==lv[:,col]%3).all():return (a,b,c,k)
    return None
C={cols[j]:coef(j) for j in range(8)};print("GF(3) linear forms (a,b,c[,const]) per factor:",C)
def norm(v):                                   # projective normalisation: first nonzero entry = 1
    v=[x%3 for x in v]
    for x in v:
        if x!=0:inv=1 if x==1 else 2;return tuple((y*inv)%3 for y in v)
    return None
cls={f:norm(C[f][:3]) for f in cols};allc=sorted({norm(v) for v in it.product(range(3),repeat=3) if any(v)});free=[c for c in allc if c not in cls.values()]
print("13 columns:",len(allc),"| used:",len(cls),"| free:",free)
rows=[]
for a,b in it.combinations(cols,2):
    u,v=cls[a],cls[b];c1=norm([(x+y) for x,y in zip(u,v)]);c2=norm([(x-y) for x,y in zip(u,v)])
    nm={v_:k for k,v_ in cls.items()}
    rows.append(dict(pair=f"{a}×{b}",comp1=(nm[c1] if c1 in nm else f"free {free.index(c1)+1}"),comp2=(nm[c2] if c2 in nm else f"free {free.index(c2)+1}")))
A=pd.DataFrame(rows);A["n_free"]=A.apply(lambda r:sum(str(x).startswith("free") for x in (r.comp1,r.comp2)),axis=1);A.to_csv("out/alias_structure.csv",index=False);pd.set_option("display.width",200);print(A.to_string())
print("pairs with 2 free comps:",(A.n_free==2).sum(),"| 1 free:",(A.n_free==1).sum(),"| 0 free:",(A.n_free==0).sum())
al={f:[r.pair for r in A.itertuples() if f in (r.comp1,r.comp2)] for f in cols};print({k:len(v) for k,v in al.items()});pd.Series({k:", ".join(v) for k,v in al.items()}).to_csv("out/main_effect_aliases.csv")
# --- SS of the five free columns (each 2 df) from the 27 run means, and pure-error / lack-of-fit ANOVA for all six responses
def free_ss(y27,fc):
    key=(fc[0]*X[:,0]+fc[1]*X[:,1]+fc[2]*X[:,2])%3;g=pd.Series(y27).groupby(key).mean();n=pd.Series(y27).groupby(key).size();return (n*(g-y27.mean())**2).sum()*3   # x3 replicates
res=[];fcol=[]
for r in RESP:
    y=B[r].values;gm=y.mean();sst=((y-gm)**2).sum();ssf={f:(B.groupby(f)[r].size()*(B.groupby(f)[r].mean()-gm)**2).sum() for f in cols}
    runm=B.groupby("Run")[r].transform("mean");sspe=((y-runm)**2).sum();ssres=sst-sum(ssf.values());sslof=ssres-sspe;mspe=sspe/54;mslof=sslof/10;Flof=mslof/mspe;plof=1-stats.f.cdf(Flof,10,54)
    y27=B.groupby("Run")[r].mean().values;fs=[free_ss(y27,f) for f in free]
    res.append(dict(Response=r,SST=sst,SS_factors=sum(ssf.values()),SS_LOF=sslof,SS_PE=sspe,SS_res=ssres,MS_LOF=mslof,MS_PE=mspe,F_LOF=Flof,p_LOF=plof,LOF_pct_of_SST=sslof/sst*100,PE_pct=sspe/sst*100,
        **{f"F_{f}":(ssf[f]/2)/mspe for f in cols},**{f"pct_{f}":ssf[f]/sst*100 for f in cols},**{f"free{i+1}":s for i,s in enumerate(fs)}))
R=pd.DataFrame(res);R.to_csv("out/anova_lof_pe.csv",index=False);print(R[["Response","SST","SS_LOF","SS_PE","F_LOF","p_LOF","LOF_pct_of_SST","PE_pct"]].round(4).to_string())
print(R[["Response"]+[f"free{i+1}" for i in range(5)]].round(4).to_string());print(R[["Response"]+[f"pct_{f}" for f in cols]].round(2).to_string())
# --- S/N ratios (all six responses)
def sn(y,kind):
    y=np.asarray(y);return -10*np.log10(np.mean(1/y**2)) if kind=="LTB" else -10*np.log10(np.mean(y**2))
kind=dict(CoF="LTB",FS="LTB",Fade="STB",Recovery="LTB",SWR="STB",Tmax="STB");out=[]
for r in RESP:
    runs=B.groupby("Run").agg({**{c:"first" for c in cols},r:lambda y:sn(y,kind[r])}).rename(columns={r:"eta"})
    for f in cols:
        m=runs.groupby(f).eta.mean();out.append(dict(Response=r,Factor=f,Delta=m.max()-m.min(),best_level=["L1 (low)","L2 (mid)","L3 (high)"][int(np.argmax(m.values))],L1=m.iloc[0],L2=m.iloc[1],L3=m.iloc[2]))
S=pd.DataFrame(out);S["Rank"]=S.groupby("Response").Delta.rank(ascending=False).astype(int);S.to_csv("out/sn_all.csv",index=False);print(S.pivot(index="Factor",columns="Response",values="Delta").round(2).to_string());print(S.pivot(index="Factor",columns="Response",values="Rank").to_string())
