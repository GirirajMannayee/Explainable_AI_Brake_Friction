from common import *
import warnings;warnings.filterwarnings("ignore")
from scipy.stats import ks_2samp,wasserstein_distance
from sklearn.ensemble import RandomForestRegressor,GradientBoostingRegressor
from sklearn.svm import SVR
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.compose import TransformedTargetRegressor as TT
from sklearn.model_selection import KFold
from xgboost import XGBRegressor
B=pd.read_csv("dataset_81_baseline_krauss_observations.csv")
sur={r:RandomForestRegressor(n_estimators=300,min_samples_leaf=2,random_state=0).fit(B[INP].values,B[r].values) for r in RESP}
R_=B[INP].agg(["min","max"]);nf=dict(CoF=.03,FS=.02,Fade=.05,Recovery=.02,SWR=.05,Tmax=.03)
expsd=dict(CoF=.057,FS=.041,Fade=8.803,Recovery=7.127,SWR=2.081,Tmax=94.587)
def gen(kind,seed=7,n=2200):
    rng=np.random.default_rng(seed);c=pd.DataFrame()
    for v in INP:
        lo,hi=R_.loc["min",v],R_.loc["max",v]
        if kind=="uniform":c[v]=rng.uniform(lo,hi,n)
        else:c[v]=np.clip(lo+(hi-lo)*rng.integers(0,3,n)/2+rng.uniform(-.05,.05,n)*(hi-lo),lo,hi)
    for r in RESP:
        sd=nf[r]*B[r].std() if kind=="uniform" else 0.35*expsd[r]
        c[r]=sur[r].predict(c[INP].values)+rng.normal(0,sd,n)
    t=c[INP[:5]].sum(1);m=(t>=22)&(t<=40)&(c.SWR>0)&(c.Fade>=0)&(c.Fade<=100)&(c.Recovery>=0)&(c.Recovery<=100)&(c.CoF>=.25)&(c.CoF<=.6)
    return c[m].reset_index(drop=True)
rows=[];DS={}
for kind in ["uniform","design"]:
    c=gen(kind);print(kind,len(c))
    for r in RESP:
        k=ks_2samp(B[r],c[r]);rows.append(dict(Sampler=kind,Response=r,sd_ratio=c[r].std()/B[r].std(),KS=k.statistic,p=k.pvalue,mean_diff_pct=(c[r].mean()-B[r].mean())/B[r].mean()*100))
    DS[kind]=pd.concat([B[INP+RESP],c.sample(n=1119,random_state=1)[INP+RESP]],ignore_index=True)
K=pd.DataFrame(rows);K.to_csv("out/ks_samplers2.csv",index=False);print(K.round(3).to_string())
def ann():return TT(make_pipeline(StandardScaler(),MLPRegressor(hidden_layer_sizes=(64,),alpha=1,activation="tanh",early_stopping=True,n_iter_no_change=20,max_iter=500,random_state=0)),transformer=StandardScaler())
def svr():return TT(make_pipeline(StandardScaler(),SVR(C=10,gamma=.2,epsilon=.05)),transformer=StandardScaler())
M={"Gradient Boosting":lambda:GradientBoostingRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0),"Random Forest":lambda:RandomForestRegressor(150,random_state=0),"XGBoost":lambda:XGBRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0,verbosity=0),"SVR":svr,"ANN":ann}
res=[]
for kind,df in DS.items():
    Xk=df[INP].values;kf=list(KFold(5,shuffle=True,random_state=0).split(Xk))
    for name,mk in M.items():
        r2=[]
        for r in RESP:
            y=df[r].values;P=np.zeros(len(y))
            for tr,te in kf:P[te]=mk().fit(Xk[tr],y[tr]).predict(Xk[te])
            r2.append(1-((y-P)**2).sum()/((y-y.mean())**2).sum())
        res.append(dict(Dataset=kind,Model=name,meanR2=np.mean(r2),minR2=min(r2),maxR2=max(r2)));print(res[-1],flush=True)
pd.DataFrame(res).to_csv("out/model_rank_sampler.csv",index=False)
