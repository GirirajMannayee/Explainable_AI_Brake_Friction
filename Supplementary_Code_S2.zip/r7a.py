from common import *
import os,time,warnings;warnings.filterwarnings("ignore")
from sklearn.ensemble import RandomForestRegressor,GradientBoostingRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.svm import SVR
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.compose import TransformedTargetRegressor as TT
from sklearn.model_selection import GroupKFold
from xgboost import XGBRegressor
B=pd.read_csv("dataset_81_baseline_krauss_observations.csv").reset_index(drop=True)
lo=B[INP].min().values;hi=B[INP].max().values;nf=dict(CoF=.03,FS=.02,Fade=.05,Recovery=.02,SWR=.05,Tmax=.03)
def gen(Btr,seed):
    rng=np.random.default_rng(seed);sur={r:RandomForestRegressor(n_estimators=300,min_samples_leaf=2,random_state=0).fit(Btr[INP].values,Btr[r].values) for r in RESP}
    c=pd.DataFrame({v:rng.uniform(lo[i],hi[i],2200) for i,v in enumerate(INP)})
    for r in RESP:c[r]=sur[r].predict(c[INP].values)+rng.normal(0,nf[r]*Btr[r].std(),2200)
    t=c[INP[:5]].sum(1);m=(t>=22)&(t<=40)&(c.SWR>0)&(c.Fade>=0)&(c.Fade<=100)&(c.Recovery>=0)&(c.Recovery<=100)&(c.CoF>=.25)&(c.CoF<=.6)
    return c[m].sample(n=min(1119,m.sum()),random_state=1).reset_index(drop=True)[INP+RESP]
def ann(**k):return TT(make_pipeline(StandardScaler(),MLPRegressor(max_iter=500,tol=1e-4,n_iter_no_change=20,early_stopping=True,random_state=0,**k)),transformer=StandardScaler())
def svr(**k):return TT(make_pipeline(StandardScaler(),SVR(epsilon=.05,**k)),transformer=StandardScaler())
GRID={"Linear Regression":[dict()],
 "Random Forest":[dict(min_samples_leaf=1),dict(min_samples_leaf=3)],
 "Support Vector Regression":[dict(C=C,gamma=g) for C in (1,10) for g in (.05,.2)],
 "Gradient Boosting":[dict(max_depth=3),dict(max_depth=4)],
 "XGBoost":[dict(max_depth=3),dict(max_depth=5)],
 "ANN (MLP)":[dict(hidden_layer_sizes=(16,),alpha=1,activation="tanh"),dict(hidden_layer_sizes=(64,),alpha=1,activation="tanh"),dict(hidden_layer_sizes=(64,),alpha=3,activation="relu")]}
MK={"Linear Regression":lambda **k:LinearRegression(),"Random Forest":lambda **k:RandomForestRegressor(150,random_state=0,**k),"Support Vector Regression":svr,
 "Gradient Boosting":lambda **k:GradientBoostingRegressor(n_estimators=300,learning_rate=.05,random_state=0,**k),"XGBoost":lambda **k:XGBRegressor(n_estimators=300,learning_rate=.05,random_state=0,verbosity=0,**k),"ANN (MLP)":ann}
def select(train_df,runs,use_syn,fold_seed):
    gkf=GroupKFold(3);best={}
    inner=[]
    for a,b in gkf.split(train_df,groups=runs):
        tr=train_df.iloc[a];va=train_df.iloc[b]
        if use_syn:tr=pd.concat([tr,gen(tr,fold_seed*10+len(inner)).iloc[:500]],ignore_index=True)
        inner.append((tr,va))
    for mn,grid in GRID.items():
        for r in RESP:
            sc=[]
            for cfg in grid:
                e=[]
                for tr,va in inner:
                    m=MK[mn](**cfg).fit(tr[INP].values,tr[r].values);e.append(np.mean((m.predict(va[INP].values)-va[r].values)**2))
                sc.append(np.mean(e))
            best[(mn,r)]=int(np.argmin(sc))
    return best
fo="out/abl_preds.csv";fs_="out/abl_sel.csv"
ro=pd.read_csv(fo).to_dict("records") if os.path.exists(fo) else [];rs=pd.read_csv(fs_).to_dict("records") if os.path.exists(fs_) else []
done={r["fold"] for r in ro};T0=time.time()
perm=np.random.default_rng(100).permutation(27)+1;groups={run:i%9 for i,run in enumerate(perm)};gid=B.Run.map(groups).values
for k in range(9):
    if k in done:continue
    if time.time()-T0>150:break
    te=np.where(gid==k)[0];tr=np.where(gid!=k)[0];Btr=B.iloc[tr][INP+RESP+["Run"]].reset_index(drop=True);Bte=B.iloc[te]
    syn=gen(Btr,7+k)
    for sname,use in [("No augmentation",False),("Leak-free augmentation",True)]:
        df=pd.concat([Btr[INP+RESP],syn],ignore_index=True) if use else Btr[INP+RESP]
        sel=select(Btr,Btr.Run.values,use,k)
        for mn in GRID:
            P={}
            for r in RESP:
                cfg=GRID[mn][sel[(mn,r)]];P[r]=MK[mn](**cfg).fit(df[INP].values,df[r].values).predict(Bte[INP].values);rs.append(dict(fold=k,Setting=sname,Model=mn,Response=r,cfg=str(cfg)))
            for i,idx in enumerate(Bte.index):ro.append(dict(fold=k,Setting=sname,Model=mn,row=idx,Run=int(Bte.loc[idx,"Run"]),**{f"y_{r}":Bte.loc[idx,r] for r in RESP},**{f"p_{r}":P[r][i] for r in RESP}))
    pd.DataFrame(ro).to_csv(fo,index=False);pd.DataFrame(rs).to_csv(fs_,index=False);print("fold",k,round(time.time()-T0),flush=True)
print(len({r["fold"] for r in ro}),"of 9 folds")
