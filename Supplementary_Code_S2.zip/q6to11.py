from common import *
import warnings;warnings.filterwarnings("ignore")
from xgboost import XGBRegressor
from sklearn.ensemble import RandomForestRegressor
from scipy.stats import ks_2samp
B=pd.read_csv("dataset_81_baseline_krauss_observations.csv")
# --- A. re-run the augmentation exactly as in 03 to get counts
rng=np.random.default_rng(7);sur={r:RandomForestRegressor(n_estimators=300,min_samples_leaf=2,random_state=0).fit(B[INP].values,B[r].values) for r in RESP}
rg={c:(B[c].min(),B[c].max()) for c in INP};cand=pd.DataFrame({c:rng.uniform(*rg[c],2200) for c in INP})
nf=dict(CoF=.03,FS=.02,Fade=.05,Recovery=.02,SWR=.05,Tmax=.03)
for r in RESP:cand[r]=sur[r].predict(cand[INP].values)+rng.normal(0,nf[r]*B[r].std(),2200)
tr=cand[["NR","NBR","SBR","EPDM","MSR"]].sum(1)
mask=(tr>=22)&(tr<=40)&(cand.SWR>0)&(cand.Fade>=0)&(cand.Fade<=100)&(cand.Recovery>=0)&(cand.Recovery<=100)&(cand.CoF>=.25)&(cand.CoF<=.6)
print("retained",mask.sum(),round(mask.mean()*100,1));print("rubber-total fails",((tr<22)|(tr>40)).sum(), "CoF fails",((cand.CoF<.25)|(cand.CoF>.6)).sum())
print("baseline RF OOB-like check: noise SD frac", {r:round(nf[r]*B[r].std(),4) for r in RESP})
# --- B. domain
print(D[INP].agg(["min","max"]).round(3).T)
print("total rubber",D[["NR","NBR","SBR","EPDM","MSR"]].sum(1).agg(["min","max"]).round(2).to_dict())
print(D[RESP].agg(["min","max"]).round(3).T)
# extrapolation test: train on lower 2/3 of one variable, test on top 1/3 (vs random)
def fit_eval(tri,tei):
    out=[]
    for r in RESP:
        m=XGBRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0,verbosity=0).fit(D.loc[tri,INP],D.loc[tri,r])
        p=m.predict(D.loc[tei,INP]);y=D.loc[tei,r].values;out.append((1-((y-p)**2).sum()/((y-y.mean())**2).sum(),np.sqrt(((y-p)**2).mean())/ (D[r].max()-D[r].min())*100))
    return np.array(out)
rows=[]
for v in INP:
    q=D[v].quantile(2/3);tri=D.index[D[v]<=q];tei=D.index[D[v]>q];e=fit_eval(tri,tei)
    # matched-size random split
    rs=np.random.default_rng(0);idx=rs.permutation(1200);n=len(tei);e0=fit_eval(idx[n:],idx[:n])
    rows.append(dict(Variable=v,n_test=n,R2_extrap=e[:,0].mean(),NRMSE_extrap=e[:,1].mean(),R2_random=e0[:,0].mean(),NRMSE_random=e0[:,1].mean()))
X1=pd.DataFrame(rows);print(X1.round(3));X1.to_csv("out/extrapolation.csv",index=False)
