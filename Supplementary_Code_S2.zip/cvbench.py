from common import *
import time,os,json
from sklearn.model_selection import KFold,RepeatedKFold,GridSearchCV,ParameterGrid
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.compose import TransformedTargetRegressor as TT
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor,GradientBoostingRegressor
from sklearn.svm import SVR
from sklearn.neural_network import MLPRegressor
from xgboost import XGBRegressor
def ann(**k):return TT(make_pipeline(StandardScaler(),MLPRegressor(max_iter=500,random_state=0,**k)),transformer=StandardScaler())
def svr(**k):return TT(make_pipeline(StandardScaler(),SVR(**k)),transformer=StandardScaler())
TUNE={
 "Linear Regression":(lambda:LinearRegression(),{}),
 "Random Forest":(lambda:RandomForestRegressor(150,random_state=0),{"min_samples_leaf":[1,3],"max_features":[1.0,0.5]}),
 "Gradient Boosting":(lambda:GradientBoostingRegressor(random_state=0),{"n_estimators":[150,300],"max_depth":[3,4],"learning_rate":[.05]}),
 "XGBoost":(lambda:XGBRegressor(random_state=0,verbosity=0,learning_rate=.05),{"n_estimators":[300,600],"max_depth":[3,5]}),
 "Support Vector Regression":(None,[dict(C=C,gamma=g,epsilon=.05) for C in (1,10,100) for g in (.05,.2)]),
 "ANN (MLP)":(None,[dict(hidden_layer_sizes=h,alpha=a,activation=ac,early_stopping=True,n_iter_no_change=20) for h,a,ac in [((16,),1,"tanh"),((64,),1,"tanh"),((64,32),1,"tanh"),((64,),3,"relu"),((64,32),3,"relu"),((32,),.1,"tanh")]]),
}
def best_cfg(name,xtr,ytr):
    inner=KFold(3,shuffle=True,random_state=1)
    if name=="Linear Regression":return LinearRegression()
    if name in("Support Vector Regression","ANN (MLP)"):
        f=svr if name.startswith("Sup") else ann;cfgs=TUNE[name][1];sc=[]
        for c in cfgs:
            e=[]
            for a,b in inner.split(xtr):
                m=f(**c).fit(xtr[a],ytr[a]);e.append(np.mean((m.predict(xtr[b])-ytr[b])**2))
            sc.append(np.mean(e))
        return f(**cfgs[int(np.argmin(sc))])
    mk,g=TUNE[name];gs=GridSearchCV(mk(),g,cv=inner,scoring="neg_mean_squared_error").fit(xtr,ytr);return gs.best_estimator_
DEF={"Linear Regression":lambda:LinearRegression(),"Random Forest":lambda:RandomForestRegressor(300,random_state=0),
 "Support Vector Regression":lambda:make_pipeline(StandardScaler(),SVR(C=10,epsilon=.01)),
 "Gradient Boosting":lambda:GradientBoostingRegressor(random_state=0),
 "XGBoost":lambda:XGBRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0,verbosity=0),
 "ANN (MLP)":lambda:make_pipeline(StandardScaler(),MLPRegressor(hidden_layer_sizes=(64,32),max_iter=3000,random_state=0))}
mode=os.sys.argv[1];fn=f"out/cv_{mode}.csv"
rows=pd.read_csv(fn).to_dict("records") if os.path.exists(fn) else []
done={(r["Response"],r["Fold"],r["Model"]) for r in rows}
splits=list(KFold(5,shuffle=True,random_state=0).split(X)) if mode=="tuned" else list(RepeatedKFold(n_splits=5,n_repeats=3,random_state=0).split(X))
T0=time.time()
for resp in RESP:
    y=D[resp].values
    for k,(tr,te) in enumerate(splits):
        for name in DEF:
            if (resp,k,name) in done:continue
            if time.time()-T0>240:break
            m=best_cfg(name,X[tr],y[tr]) if mode=="tuned" else DEF[name]()
            m.fit(X[tr],y[tr]);rows.append(dict(Response=resp,Fold=k,Model=name,**metrics(y[te],m.predict(X[te]))))
        pd.DataFrame(rows).to_csv(fn,index=False)
print(mode,len(rows),"of",6*6*len(splits),round(time.time()-T0))
