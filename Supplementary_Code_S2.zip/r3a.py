from common import *
import warnings,itertools;warnings.filterwarnings("ignore")
import shap
from scipy.stats import spearmanr
from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBRegressor
B=pd.read_csv("dataset_81_baseline_krauss_observations.csv");B["tot"]=B[INP[:5]].sum(1);Bc=B[B.tot<=40].reset_index(drop=True)
print("admissible baseline rows",len(Bc),"runs",Bc.Run.nunique())
def anova_share(df,r):
    Z=(df[INP]-df[INP].mean())/df[INP].std();A=np.column_stack([np.ones(len(df)),Z.values]);y=df[r].values;c=np.linalg.lstsq(A,y,rcond=None)[0];res=y-A@c
    ss=(c[1:]**2)*((Z.values**2).sum(0));return pd.Series(ss/((y-y.mean())**2).sum()*100,INP)
def sn(df,r):
    f=(lambda y:-10*np.log10(np.mean(1/np.asarray(y)**2))) if r=="CoF" else (lambda y:-10*np.log10(np.mean(np.asarray(y)**2)))
    runs=df.groupby("Run").agg({**{c:"first" for c in INP},r:lambda y:f(y)}).rename(columns={r:"sn"});return pd.Series({c:runs.groupby(c).sn.mean().max()-runs.groupby(c).sn.mean().min() for c in INP})
rows=[]
for r in RESP:
    a=anova_share(B,r);b=anova_share(Bc,r);rows.append(dict(Response=r,rho_ANOVA=spearmanr(a,b)[0],top3_full=", ".join(a.sort_values(ascending=False).index[:3]),top3_adm=", ".join(b.sort_values(ascending=False).index[:3]),sumMain_full=a.sum(),sumMain_adm=b.sum()))
A=pd.DataFrame(rows);print(A.round(3).to_string())
sr=[]
for r in ["CoF","SWR"]:
    a=sn(B,r);b=sn(Bc,r);sr.append(dict(Response=r,rho_SN=spearmanr(a,b)[0],top3_full=", ".join(a.sort_values(ascending=False).index[:3]),top3_adm=", ".join(b.sort_values(ascending=False).index[:3])))
S=pd.DataFrame(sr);print(S.round(3).to_string());A.to_csv("out/anova_full_vs_admissible.csv",index=False);S.to_csv("out/sn_full_vs_admissible.csv",index=False)
# constrained pipeline: baseline admissible (63 rows) -> RF surface -> synthetic (Algorithm 1) -> 63 + 1137 = 1200
lo=B[INP].min().values;hi=B[INP].max().values;nf=dict(CoF=.03,FS=.02,Fade=.05,Recovery=.02,SWR=.05,Tmax=.03)
rng=np.random.default_rng(7);sur={r:RandomForestRegressor(n_estimators=300,min_samples_leaf=2,random_state=0).fit(Bc[INP].values,Bc[r].values) for r in RESP}
c=pd.DataFrame({v:rng.uniform(lo[i],hi[i],2200) for i,v in enumerate(INP)})
for r in RESP:c[r]=sur[r].predict(c[INP].values)+rng.normal(0,nf[r]*Bc[r].std(),2200)
t=c[INP[:5]].sum(1);m=(t>=22)&(t<=40)&(c.SWR>0)&(c.Fade>=0)&(c.Fade<=100)&(c.Recovery>=0)&(c.Recovery<=100)&(c.CoF>=.25)&(c.CoF<=.6)
Dc=pd.concat([Bc[INP+RESP],c[m].sample(n=1200-len(Bc),random_state=1)[INP+RESP]],ignore_index=True);Dc.to_csv("out/dataset_admissible_1200.csv",index=False);print("admissible dataset",len(Dc),"retained cand",m.sum())
print("max total rubber in admissible dataset:",Dc[INP[:5]].sum(1).max().round(2))
