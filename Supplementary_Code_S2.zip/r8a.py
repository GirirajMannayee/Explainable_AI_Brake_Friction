from common import *
import warnings,itertools,time;warnings.filterwarnings("ignore")
import shap
from scipy.stats import spearmanr
from xgboost import XGBRegressor
t0=time.time();rng=np.random.default_rng(0)
Xd=D[INP];bg=Xd.iloc[rng.choice(len(Xd),200,replace=False)];ex_idx=rng.choice(len(Xd),300,replace=False);Xe=Xd.iloc[ex_idx]
rows=[];grp=[]
G=[[0,1,2,3,4],[5],[6],[7]];gnames=["Formulation (5 rubbers)","P","V","T0"]
for r in RESP:
    m=XGBRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0,verbosity=0).fit(Xd,D[r])
    pd_=shap.TreeExplainer(m);sv_pd=pd_.shap_values(Xe)                                   # as used: tree_path_dependent, no background
    iv=shap.TreeExplainer(m,data=bg,feature_perturbation="interventional");sv_iv=iv.shap_values(Xe,check_additivity=False)
    a=np.abs(sv_pd).mean(0);b=np.abs(sv_iv).mean(0)
    rows.append(dict(Response=r,rho=spearmanr(a,b)[0],top3_pd=", ".join(pd.Series(a,INP).sort_values(ascending=False).index[:3]),top3_iv=", ".join(pd.Series(b,INP).sort_values(ascending=False).index[:3]),
        formulation_share_pd=np.abs(sv_pd[:,:5].sum(1)).mean()/np.sum([np.abs(sv_pd[:,g].sum(1)).mean() for g in G])*100,
        sum_indiv_rubber_share_pd=a[:5].sum()/a.sum()*100,indiv_rubber_share_iv=b[:5].sum()/b.sum()*100))
    # exact grouped interventional Shapley with 4 players (formulation as one player): composition stays feasible in every coalition
    Xv=Xe.values;Bv=bg.values;n=len(Xv);v={}
    for k in range(5):
        for S in itertools.combinations(range(4),k):
            cols=[c for g in S for c in G[g]];H=np.repeat(Xv,len(Bv),axis=0).copy();Bt=np.tile(Bv,(n,1))
            mask=np.ones(8,bool);mask[cols]=False;H[:,mask]=Bt[:,mask]            # features outside S are taken from the background row
            v[S]=m.predict(pd.DataFrame(H,columns=INP)).reshape(n,len(Bv)).mean(1)
    import math
    phi=np.zeros((n,4))
    for i in range(4):
        others=[j for j in range(4) if j!=i]
        for k in range(4):
            for S in itertools.combinations(others,k):
                w=math.factorial(k)*math.factorial(3-k)/math.factorial(4);phi[:,i]+=w*(v[tuple(sorted(S+(i,)))]-v[S])
    gi=np.abs(phi).mean(0);grp.append(dict(Response=r,**{gn:gi[j]/gi.sum()*100 for j,gn in enumerate(gnames)}))
    print(r,round(time.time()-t0),flush=True)
S=pd.DataFrame(rows);Gp=pd.DataFrame(grp);S.to_csv("out/shap_explainers.csv",index=False);Gp.to_csv("out/shap_grouped.csv",index=False);pd.set_option("display.width",220);print(S.round(2).to_string());print(Gp.round(1).to_string())
# composition feasibility of hybrid (interventional) coalitions
x=Xd.sample(100000,replace=True,random_state=1).values;b=Xd.sample(100000,replace=True,random_state=2).values;m=np.random.default_rng(3).random((100000,5))<0.5
hyb=np.where(m,x[:,:5],b[:,:5]).sum(1);part=m.any(1)&(~m.all(1))
print("hybrid coalitions with a partial set of rubbers from x and the rest from background: share outside 22-40 wt.% =",round(((hyb<22)|(hyb>40))[part].mean()*100,1),"%; outside 22-44:",round(((hyb<22)|(hyb>44))[part].mean()*100,1),"%; baseline share of the data itself outside 22-40:",round(((Xd.iloc[:,:5].sum(1)<22)|(Xd.iloc[:,:5].sum(1)>40)).mean()*100,1),"%")
print("input correlations (max |r| among rubbers):",np.abs(np.corrcoef(Xd.values[:,:5].T)-np.eye(5)).max().round(3),"| max |r| of all 8:",np.abs(np.corrcoef(Xd.values.T)-np.eye(8)).max().round(3))
