from common import *
import os,time,warnings;warnings.filterwarnings("ignore")
from sklearn.ensemble import RandomForestRegressor,GradientBoostingRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.compose import TransformedTargetRegressor as TT
from xgboost import XGBRegressor
B=pd.read_csv("dataset_81_baseline_krauss_observations.csv").reset_index(drop=True)
syn_all=D[D.Source!="experimental_baseline"].reset_index(drop=True)
lo=B[INP].min().values;hi=B[INP].max().values;nf=dict(CoF=.03,FS=.02,Fade=.05,Recovery=.02,SWR=.05,Tmax=.03)
def gen(Btr,seed):
    rng=np.random.default_rng(seed);sur={r:RandomForestRegressor(n_estimators=300,min_samples_leaf=2,random_state=0).fit(Btr[INP].values,Btr[r].values) for r in RESP}
    c=pd.DataFrame({v:rng.uniform(lo[i],hi[i],2200) for i,v in enumerate(INP)})
    for r in RESP:c[r]=sur[r].predict(c[INP].values)+rng.normal(0,nf[r]*Btr[r].std(),2200)
    t=c[INP[:5]].sum(1);m=(t>=22)&(t<=40)&(c.SWR>0)&(c.Fade>=0)&(c.Fade<=100)&(c.Recovery>=0)&(c.Recovery<=100)&(c.CoF>=.25)&(c.CoF<=.6)
    return c[m].sample(n=min(1119,m.sum()),random_state=1).reset_index(drop=True),sur
def ann():return TT(make_pipeline(StandardScaler(),MLPRegressor(hidden_layer_sizes=(64,),alpha=1,activation="tanh",early_stopping=True,n_iter_no_change=20,max_iter=500,random_state=0)),transformer=StandardScaler())
M={"XGBoost":lambda:XGBRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0,verbosity=0),"Gradient Boosting":lambda:GradientBoostingRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0),"Random Forest":lambda:RandomForestRegressor(150,random_state=0),"ANN":ann}
fo="out/lk2_orig.csv";fg="out/lk2_gen.csv"
ro=pd.read_csv(fo).to_dict("records") if os.path.exists(fo) else [];rg=pd.read_csv(fg).to_dict("records") if os.path.exists(fg) else []
done={(r["rep"],r["fold"]) for r in ro};T0=time.time()
for rep in range(3):
    perm=np.random.default_rng(100+rep).permutation(27)+1;groups={run:i%9 for i,run in enumerate(perm)}
    gid=B.Run.map(groups).values
    for k in range(9):
        if (rep,k) in done:continue
        if time.time()-T0>215:break
        te=np.where(gid==k)[0];tr=np.where(gid!=k)[0];Btr,Bte=B.iloc[tr],B.iloc[te]
        # generated sets: leak-free generator (training runs only) and leaky generator (all 81, as in the paper)
        sl,_=gen(Btr,7+k+10*rep);sk=syn_all.sample(frac=1,random_state=rep).reset_index(drop=True)
        def split(s):n=int(.2*len(s));return s.iloc[n:].reset_index(drop=True),s.iloc[:n].reset_index(drop=True)
        slf_tr,slf_te=split(sl);sk_tr,sk_te=split(sk[INP+RESP])
        sets={"Baseline only":(Btr[INP+RESP],{}),"Leaky generator (as in paper)":(pd.concat([Btr[INP+RESP],sk_tr],ignore_index=True),{"gen":sk_te}),"Leak-free generator":(pd.concat([Btr[INP+RESP],slf_tr[INP+RESP]],ignore_index=True),{"gen":slf_te[INP+RESP]})}
        for sname,(df,extra) in sets.items():
            for mn,mk in M.items():
                P={};Pg={}
                for r in RESP:
                    m=mk().fit(df[INP].values,df[r].values);P[r]=m.predict(Bte[INP].values)
                    if "gen" in extra:Pg[r]=m.predict(extra["gen"][INP].values)
                for i,idx in enumerate(Bte.index):ro.append(dict(rep=rep,fold=k,Setting=sname,Model=mn,row=idx,**{f"y_{r}":Bte.loc[idx,r] for r in RESP},**{f"p_{r}":P[r][i] for r in RESP}))
                if "gen" in extra:
                    for r in RESP:
                        y=extra["gen"][r].values;p=Pg[r];rg.append(dict(rep=rep,fold=k,Setting=sname,Model=mn,Response=r,R2=1-((y-p)**2).sum()/((y-y.mean())**2).sum(),RMSE=float(np.sqrt(((y-p)**2).mean())),n=len(y)))
        # generator surface itself used as a predictor of the held-out original rows (leak-free: fitted on training runs)
        _,sur=gen(Btr,7+k+10*rep)
        for i,idx in enumerate(Bte.index):ro.append(dict(rep=rep,fold=k,Setting="Generator surface (fitted on training runs)",Model="Random-forest surface",row=idx,**{f"y_{r}":Bte.loc[idx,r] for r in RESP},**{f"p_{r}":sur[r].predict(Bte[INP].values[[i]])[0] for r in RESP}))
        pd.DataFrame(ro).to_csv(fo,index=False);pd.DataFrame(rg).to_csv(fg,index=False);print("rep",rep,"fold",k,round(time.time()-T0),flush=True)
print(len({(r['rep'],r['fold']) for r in ro}),"of 27 folds done")
