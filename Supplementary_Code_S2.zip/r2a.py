from common import *
import warnings;warnings.filterwarnings("ignore")
from scipy.stats import ks_2samp,wasserstein_distance
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import LeaveOneGroupOut
B=pd.read_csv("dataset_81_baseline_krauss_observations.csv")
sur={r:RandomForestRegressor(n_estimators=300,min_samples_leaf=2,random_state=0).fit(B[INP].values,B[r].values) for r in RESP}
rng_=B[INP].agg(["min","max"]);nf=dict(CoF=.03,FS=.02,Fade=.05,Recovery=.02,SWR=.05,Tmax=.03)
def gen(kind,seed=7,n=2200):
    rng=np.random.default_rng(seed);lo=rng_.loc["min"].values;hi=rng_.loc["max"].values
    if kind=="uniform":X=rng.uniform(lo,hi,(n,8))
    else:
        lev=rng.integers(0,3,(n,8));X=lo+(hi-lo)*(lev/2)+rng.uniform(-.05,.05,(n,8))*(hi-lo);X=np.clip(X,lo,hi)   # design levels + 5% jitter
    c=pd.DataFrame(X,columns=INP)
    for r in RESP:c[r]=sur[r].predict(X)+rng.normal(0,nf[r]*B[r].std(),n)
    t=c[INP[:5]].sum(1);m=(t>=22)&(t<=40)&(c.SWR>0)&(c.Fade>=0)&(c.Fade<=100)&(c.Recovery>=0)&(c.Recovery<=100)&(c.CoF>=.25)&(c.CoF<=.6)
    return c[m].reset_index(drop=True),m.mean()
out=[]
for kind in ["uniform","design-matched"]:
    c,fr=gen(kind);print(kind,len(c),round(fr*100,1))
    print(" input SD ratio syn/exp:",{v:round(c[v].std()/B[v].std(),2) for v in INP[:5]+["T0"]})
    for r in RESP:
        k=ks_2samp(B[r],c[r]);out.append(dict(Sampler=kind,Response=r,n_syn=len(c),exp_mean=B[r].mean(),syn_mean=c[r].mean(),mean_diff_pct=(c[r].mean()-B[r].mean())/B[r].mean()*100,exp_sd=B[r].std(),syn_sd=c[r].std(),sd_ratio=c[r].std()/B[r].std(),KS=k.statistic,p=k.pvalue,W=wasserstein_distance(B[r],c[r])))
    c.to_csv(f"out/synth_{kind}.csv",index=False)
O=pd.DataFrame(out);O.to_csv("out/ks_samplers.csv",index=False);pd.set_option("display.width",200);print(O.round(3).to_string())
# leave-one-design-point-out fidelity of the RF response surface
grp=B.Run.values;res=[]
for r in RESP:
    P=np.zeros(81)
    for tr,te in LeaveOneGroupOut().split(B,groups=grp):
        m=RandomForestRegressor(n_estimators=300,min_samples_leaf=2,random_state=0).fit(B.loc[tr,INP].values,B.loc[tr,r].values);P[te]=m.predict(B.loc[te,INP].values)
    y=B[r].values;res.append(dict(Response=r,R2_LODO=1-((y-P)**2).sum()/((y-y.mean())**2).sum(),RMSE=np.sqrt(((y-P)**2).mean()),SD=y.std(),RMSE_over_SD=np.sqrt(((y-P)**2).mean())/y.std()))
Lr=pd.DataFrame(res);Lr.to_csv("out/lodo.csv",index=False);print(Lr.round(3).to_string())
# runs above 40 wt%
t=B.groupby("Run")[INP[:5]].first().sum(1);print("runs >40:",{int(k):v for k,v in t[t>40].items()},"n runs",(t>40).sum())
