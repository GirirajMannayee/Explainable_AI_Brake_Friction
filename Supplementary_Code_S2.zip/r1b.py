from common import *
import warnings,itertools;warnings.filterwarnings("ignore")
import shap
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import KFold
from xgboost import XGBRegressor
# ---- (b) constraint-violation sensitivity
D["tot"]=D[INP[:5]].sum(1);bad=(D.tot>40)|(D.Tmax<D.T0)|(D.Fade<0)|(D.Fade>100)|(D.Recovery>100)
print("rows violating >=1 stated constraint:",bad.sum(),"| tot>40:",(D.tot>40).sum(),"| Tmax<T0:",(D.Tmax<D.T0).sum(),"| Fade<0:",(D.Fade<0).sum(),"| Recovery>100:",(D.Recovery>100).sum(),"| CoF out of 0.25-0.6:",((D.CoF<.25)|(D.CoF>.6)).sum())
mk=lambda:XGBRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0,verbosity=0)
def cv(df):
    Xk=df[INP].values;kf=list(KFold(5,shuffle=True,random_state=0).split(Xk));o=[]
    for r in RESP:
        y=df[r].values;P=np.zeros(len(y))
        for a,b in kf:P[b]=mk().fit(Xk[a],y[a]).predict(Xk[b])
        o.append(1-((y-P)**2).sum()/((y-y.mean())**2).sum())
    return np.mean(o)
C=D[~bad].reset_index(drop=True);print("clean rows",len(C),"CV R2 all",round(cv(D),4),"clean",round(cv(C),4))
for resp in ["CoF","SWR","Fade"]:
    o=[]
    for df in (D,C):
        m=mk().fit(df[INP],df[resp]);sv=np.abs(shap.TreeExplainer(m).shap_values(df[INP])).mean(0);o.append(pd.Series(sv,INP).sort_values(ascending=False))
    print(resp,"SHAP order all:",list(o[0].index[:5]),"| clean:",list(o[1].index[:5]),"| shares",(o[0]/o[0].sum()*100).round(1).head(3).to_dict(),(o[1]/o[1].sum()*100).round(1).head(3).to_dict())
# ---- (c) polynomial representation of the generator mean surface (RF fitted to 81 baseline rows)
B=pd.read_csv("dataset_81_baseline_krauss_observations.csv");lo=B[INP].min().values;hi=B[INP].max().values
rng=np.random.default_rng(11);U=rng.uniform(lo,hi,(20000,8));mu=U.mean(0);sd=U.std(0)
def feats(X):
    Z=(X-mu)/sd;cols=[Z]+[Z**2]+[ (Z[:,i]*Z[:,j])[:,None] for i,j in itertools.combinations(range(8),2)]
    names=INP+[f"{v}^2" for v in INP]+[f"{INP[i]}x{INP[j]}" for i,j in itertools.combinations(range(8),2)]
    return np.column_stack([np.ones(len(X))]+cols),["Intercept"]+names
Fm,names=feats(U);coef={};r2={}
Ut=rng.uniform(lo,hi,(10000,8));Ft,_=feats(Ut)
for r in RESP:
    rf=RandomForestRegressor(n_estimators=300,min_samples_leaf=2,random_state=0).fit(B[INP].values,B[r].values)
    y=rf.predict(U);b=np.linalg.lstsq(Fm,y,rcond=None)[0];coef[r]=b;yt=rf.predict(Ut);pt=Ft@b;r2[r]=1-((yt-pt)**2).sum()/((yt-yt.mean())**2).sum()
Cf=pd.DataFrame(coef,index=names);Cf.to_csv("out/generator_polynomial_coefficients.csv");print("polynomial R2 vs RF surface (held-out uniform points):",{k:round(v,3) for k,v in r2.items()})
print("inputs standardised with mean",dict(zip(INP,mu.round(3))),"sd",dict(zip(INP,sd.round(3))))
print(Cf.loc[["Intercept"]+INP].round(4).to_string())
for r in RESP:
    top=Cf[r].iloc[17:].abs().sort_values(ascending=False).head(3);print(r,"top interactions",{k:round(Cf.loc[k,r],4) for k in top.index})
