src=open("nsga_conv.py").read().split("import sys,os")[0];exec(src)
import shap,itertools
from scipy.stats import spearmanr
from sklearn.model_selection import KFold
from sklearn.ensemble import RandomForestRegressor,GradientBoostingRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.compose import TransformedTargetRegressor as TT
B=pd.read_csv("dataset_81_baseline_krauss_observations.csv").reset_index(drop=True)
# ---------- temperature-consistent dataset: clip baseline Tmax at T0, regenerate synthetic with the dT model and constraint Tmax>=T0
Bc=B.copy();viol=(Bc.Tmax<Bc.T0);print("baseline rows with Tmax<T0:",int(viol.sum()),"in runs",sorted(Bc[viol].Run.unique()));Bc["Tmax"]=np.maximum(Bc.Tmax,Bc.T0)
lo=B[INP].min().values;hi=B[INP].max().values;nf=dict(CoF=.03,FS=.02,Fade=.05,Recovery=.02,SWR=.05,Tmax=.03)
rng=np.random.default_rng(7);c=pd.DataFrame({v:rng.uniform(lo[i],hi[i],2200) for i,v in enumerate(INP)})
for r in RESP:
    if r=="Tmax":
        y=(Bc.Tmax-Bc.T0).values;m=RandomForestRegressor(n_estimators=300,min_samples_leaf=2,random_state=0).fit(Bc[INP].values,y);c["Tmax"]=c.T0+m.predict(c[INP].values)+rng.normal(0,nf[r]*y.std(),2200)
    else:
        m=RandomForestRegressor(n_estimators=300,min_samples_leaf=2,random_state=0).fit(Bc[INP].values,Bc[r].values);c[r]=m.predict(c[INP].values)+rng.normal(0,nf[r]*Bc[r].std(),2200)
t=c[INP[:5]].sum(1);ok=(t>=22)&(t<=40)&(c.SWR>0)&(c.Fade>=0)&(c.Fade<=100)&(c.Recovery>=0)&(c.Recovery<=100)&(c.CoF>=.25)&(c.CoF<=.6)&(c.Tmax>=c.T0)
print("retained",int(ok.sum()),"of 2200")
DC=pd.concat([Bc[INP+RESP].assign(Source="baseline (Tmax clipped at T0)"),c[ok].sample(n=1119,random_state=1)[INP+RESP].assign(Source="synthetic v2")],ignore_index=True);DC.to_csv("out/dataset_consistent.csv",index=False)
print("DC violations Tmax<T0:",int((DC.Tmax<DC.T0).sum()),"| total rubber max",DC[INP[:5]].sum(1).max().round(1),"| Fade<0:",int((DC.Fade<0).sum()))
# ---------- effect on models and SHAP
def ann():return TT(make_pipeline(StandardScaler(),MLPRegressor(hidden_layer_sizes=(64,),alpha=1,activation="tanh",early_stopping=True,n_iter_no_change=20,max_iter=500,random_state=0)),transformer=StandardScaler())
M={"Gradient Boosting":lambda:GradientBoostingRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0),"Random Forest":lambda:RandomForestRegressor(150,random_state=0),"XGBoost":lambda:XGBRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0,verbosity=0),"ANN":ann}
res=[]
for nm,df in [("Paper data set",D[INP+RESP]),("Temperature-consistent data set",DC[INP+RESP])]:
    Xk=df[INP].values;kf=list(KFold(5,shuffle=True,random_state=0).split(Xk))
    for mn,mk in M.items():
        r2=[]
        for r in RESP:
            y=df[r].values;P=np.zeros(len(y))
            for a,b in kf:P[b]=mk().fit(Xk[a],y[a]).predict(Xk[b])
            r2.append(1-((y-P)**2).sum()/((y-y.mean())**2).sum())
        res.append(dict(Dataset=nm,Model=mn,meanR2=np.mean(r2)))
    for resp in ["CoF","SWR","Tmax"]:
        m=XGBRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0,verbosity=0).fit(df[INP],df[resp]);sv=np.abs(shap.TreeExplainer(m).shap_values(df[INP])).mean(0)
        res.append(dict(Dataset=nm,Model="SHAP "+resp,top5=", ".join(pd.Series(sv,INP).sort_values(ascending=False).index[:5])))
R=pd.DataFrame(res);R.to_csv("out/consistent_models_shap.csv",index=False);print(R.to_string())
# ---------- NSGA-II with the temperature constraint
OBJ=["CoF","FS","Fade","Recovery","SWR","Tmax"];HIGH=[True,True,False,True,False,False]
class Pb2(Problem):
    def __init__(s):super().__init__(n_var=8,n_obj=6,n_constr=3,xl=xl,xu=xu)
    def _evaluate(s,x,out,*a,**k):
        d=pd.DataFrame(x,columns=INP);p={r:SUR[r].predict(d) for r in RESP}
        out["F"]=np.column_stack([-p["CoF"],-p["FS"],p["Fade"],-p["Recovery"],p["SWR"],p["Tmax"]]);tt=x[:,:5].sum(1);out["G"]=np.column_stack([22-tt,tt-40,x[:,7]-p["Tmax"]])
def frontP(prob,seed=1,ng=150,pop=120):
    alg=NSGA2(pop_size=pop,sampling=FloatRandomSampling(),crossover=SBX(eta=15,prob=.9),mutation=PM(eta=20),eliminate_duplicates=True);r=minimize(prob,alg,("n_gen",ng),seed=seed,verbose=False);pf=pd.DataFrame(r.X,columns=INP);F=r.F
    for n,v in zip(OBJ,[-F[:,0],-F[:,1],F[:,2],-F[:,3],F[:,4],F[:,5]]):pf[n]=v
    return pf
def pick(pf):
    N=pd.DataFrame({r:((pf[r]-pf[r].min())/(pf[r].max()-pf[r].min()+1e-12)) if h else 1-((pf[r]-pf[r].min())/(pf[r].max()-pf[r].min()+1e-12)) for r,h in zip(OBJ,HIGH)});s=N.sum(1).where(pf.Fade>1.0,-1e9);return pf.loc[int(s.argmax())]
out=[]
for nm,df,prob in [("Paper data set, no temperature constraint (as in the paper)",D,Pb),("Paper data set, Tmax >= T0 enforced",D,Pb2),("Temperature-consistent data set, Tmax >= T0 enforced",DC,Pb2)]:
    SUR={r:XGBRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0,verbosity=0).fit(df[INP],df[r]) for r in RESP};sur=SUR   # sur is used by Pb of nsga_conv
    pf=frontP(prob());b=pick(pf);nviol=int((pf.Tmax<pf.T0).sum());out.append(dict(Problem=nm,n_front=len(pf),n_Tmax_below_T0=nviol,**{k:b[k] for k in INP+OBJ}))
O=pd.DataFrame(out);O.to_csv("out/consistent_nsga.csv",index=False);pd.set_option("display.width",250);print(O.round(3).T.to_string())
