from common import *
import matplotlib;matplotlib.use("Agg");import matplotlib.pyplot as plt,glob
plt.rcParams.update({"font.size":9,"font.family":"serif"})
# Fig A: ANN ablation
a=pd.read_csv("out/ann_ablation.csv");g=a.groupby(["Factor","Setting"],sort=False).R2.mean().reset_index()
fig,ax=plt.subplots(figsize=(7,6));cols={f:c for f,c in zip(g.Factor.unique(),plt.cm.tab10.colors)}
lab=[f"{f}: {s}" for f,s in zip(g.Factor,g.Setting)];ax.barh(range(len(g)),g.R2,color=[cols[f] for f in g.Factor]);ax.set_yticks(range(len(g)));ax.set_yticklabels(lab,fontsize=7);ax.invert_yaxis()
ax.set_xlabel("Mean 5-fold CV R² over six responses");ax.axvline(.965,ls="--",c="k",lw=.8);ax.text(.955,len(g)-1,"XGBoost / GB (≈0.97)",ha="right",fontsize=7);plt.tight_layout();plt.savefig("out/figA_ann_ablation.png",dpi=200);plt.close()
# Fig B: SHAP vs ANOVA interaction for CoF and SWR
R=pd.read_csv("out/shap_vs_anova_pairs.csv");fig,axs=plt.subplots(1,2,figsize=(7.5,3.4))
for ax,r in zip(axs,["CoF","SWR"]):
    d=R[R.Response==r];ax.scatter(d.ANOVA_SS_pct,d.SHAP_share_pct,s=14)
    for _,q in d.sort_values("SHAP_share_pct").tail(4).iterrows():ax.annotate(q.Pair,(q.ANOVA_SS_pct,q.SHAP_share_pct),fontsize=7)
    ax.set_xlabel("ANOVA interaction SS (% of total SS)");ax.set_ylabel("SHAP interaction (% of total attribution)");ax.set_title(r)
plt.tight_layout();plt.savefig("out/figB_shap_anova.png",dpi=200);plt.close()
# Fig C: NSGA-II convergence
t=pd.concat([pd.read_csv(x) for x in glob.glob("out/nsga_traces_*.csv")]);s=t.groupby("gen").HV.agg(["mean","std"]).reset_index();r=pd.read_csv("out/nsga_trace_seed1.csv");sn=pd.read_csv("out/nsga_sensitivity.csv").groupby(["pop","gen"]).HV.mean().reset_index()
fig,axs=plt.subplots(1,2,figsize=(7.5,3.2));ax=axs[0]
ax.plot(r.gen,r.HV,c="grey",lw=1,label="Seed 1, 500 gen");ax.plot(s.gen,s["mean"],c="C0",label="Mean of 10 seeds (150 gen)");ax.fill_between(s.gen,s["mean"]-s["std"],s["mean"]+s["std"],alpha=.25);ax.axvline(150,ls="--",c="k",lw=.8)
ax.set_xlabel("Generation");ax.set_ylabel("Hypervolume (normalised)");ax.legend(fontsize=7)
ax=axs[1];d=sn[sn["pop"]==120];ax.plot(d.gen,d.HV,"o-",label="pop 120")
ax.plot([150,150],[sn[(sn["pop"]==60)&(sn.gen==150)].HV.iloc[0],sn[(sn["pop"]==240)&(sn.gen==150)].HV.iloc[0]],"s",c="C3",label="pop 60 / 240 @150");ax.set_xlabel("Generations");ax.set_ylabel("Hypervolume");ax.legend(fontsize=7)
plt.tight_layout();plt.savefig("out/figC_nsga_convergence.png",dpi=200);plt.close()
# tables
for m in ["tuned","default"]:
    d=pd.read_csv(f"out/cv_{m}.csv");A=d.groupby(["Response","Model"],sort=False).agg(R2=("R2","mean"),R2sd=("R2","std"),RMSE=("RMSE","mean"),RMSEsd=("RMSE","std"),MAE=("MAE","mean"),MAEsd=("MAE","std"),MAPE=("MAPE","mean")).reset_index();A.to_csv(f"out/table_cv_{m}.csv",index=False)
d=pd.read_csv("out/cv_tuned.csv");rg=D[RESP].max()-D[RESP].min();sd=D[RESP].std()
A=pd.read_csv("out/table_cv_tuned.csv");A["NRMSE_range_pct"]=[r.RMSE/rg[r.Response]*100 for r in A.itertuples()];A["NMAE_range_pct"]=[r.MAE/rg[r.Response]*100 for r in A.itertuples()]
A.to_csv("out/table_cv_tuned.csv",index=False);pd.set_option("display.width",220)
print(A.round(3).to_string())
print(rg.round(3).to_dict())
