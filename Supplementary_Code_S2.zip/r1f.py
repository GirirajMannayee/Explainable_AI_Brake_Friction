from common import *
import warnings;warnings.filterwarnings("ignore")
from scipy.stats import spearmanr
src=open("r1c.py").read();i=src.index("def tests");j=src.index("T=pd.DataFrame");exec("Rg=8.314\n"+src[i:j])
B=D[D.Source=="experimental_baseline"].reset_index(drop=True);S1=D[D.Source!="experimental_baseline"].reset_index(drop=True);S2=pd.read_csv("out/synth_v2.csv")
T=pd.DataFrame({"baseline (81)":tests(B),"synthetic v1 (as used)":tests(S1),"synthetic v2":tests(S2)});T.to_csv("out/physical_table3cols.csv");pd.set_option("display.width",200);print(T.round(3).to_string())
