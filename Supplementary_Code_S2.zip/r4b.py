from common import *
import matplotlib;matplotlib.use("Agg");import matplotlib.pyplot as plt
from scipy import stats
plt.rcParams.update({"font.size":8,"font.family":"serif"})
B=pd.read_csv("dataset_81_baseline_krauss_observations.csv");R=pd.read_csv("out/anova_lof_pe.csv");S=pd.read_csv("out/sn_all.csv")
# ANOVA tables (factor rows with F vs pure error)
for r in ["CoF","SWR"]:
    y=B[r].values;gm=y.mean();sst=((y-gm)**2).sum();q=R[R.Response==r].iloc[0];rows=[]
    for f in INP:
        ss=(B.groupby(f)[r].size()*(B.groupby(f)[r].mean()-gm)**2).sum();ms=ss/2;F=ms/q.MS_PE;rows.append(dict(Source=f,SS=ss,DF=2,MS=ms,F=F,p=1-stats.f.cdf(F,2,54),pct=ss/sst*100))
    rows.append(dict(Source="Lack of fit",SS=q.SS_LOF,DF=10,MS=q.MS_LOF,F=q.F_LOF,p=q.p_LOF,pct=q.SS_LOF/sst*100));rows.append(dict(Source="Pure error",SS=q.SS_PE,DF=54,MS=q.MS_PE,F=np.nan,p=np.nan,pct=q.SS_PE/sst*100));rows.append(dict(Source="Total",SS=sst,DF=80,MS=np.nan,F=np.nan,p=np.nan,pct=100.0))
    pd.DataFrame(rows).to_csv(f"out/anova_table_{r}.csv",index=False)
# Figure 7: S/N main effects (CoF, SWR)
fig,ax=plt.subplots(2,1,figsize=(4.3,4.42),sharex=True);cols=plt.cm.tab10.colors
for a,r,lab in zip(ax,["CoF","SWR"],["CoF (larger-the-better)","SWR (smaller-the-better)"]):
    for k,f in enumerate(INP):
        d=S[(S.Response==r)&(S.Factor==f)].iloc[0];a.plot([1,2,3],[d.L1,d.L2,d.L3],"o-",ms=3,lw=1,color=cols[k],label=f)
    a.set_ylabel("Mean S/N ratio (dB)");a.set_title(lab,fontsize=8)
ax[1].set_xticks([1,2,3]);ax[1].set_xticklabels(["Level 1","Level 2","Level 3"]);ax[0].legend(ncol=4,fontsize=6,loc="best");plt.tight_layout();plt.savefig("out/fig7_new.png",dpi=200);plt.close()
# Figure 8: ANOVA contributions
fig,ax=plt.subplots(1,2,figsize=(6.2,2.07))
for a,r in zip(ax,["CoF","SWR"]):
    t=pd.read_csv(f"out/anova_table_{r}.csv");t=t[t.Source.isin(INP+["Lack of fit","Pure error"])];a.bar(range(len(t)),t.pct,color=["C0"]*5+["C1"]*3+["grey","grey"]);a.set_xticks(range(len(t)));a.set_xticklabels(t.Source,rotation=60,fontsize=6);a.set_ylabel("Contribution (%)");a.set_title(r,fontsize=8)
plt.tight_layout();plt.savefig("out/fig8_new.png",dpi=220);plt.close()
for r in ["CoF","SWR"]:print(pd.read_csv(f"out/anova_table_{r}.csv").round(4).to_string())
