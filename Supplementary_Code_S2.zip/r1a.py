from common import *
import os,time,warnings;warnings.filterwarnings("ignore")
from sklearn.ensemble import RandomForestRegressor,GradientBoostingRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.compose import TransformedTargetRegressor as TT
from sklearn.model_selection import GroupKFold
from xgboost import XGBRegressor
B=pd.read_csv("dataset_81_baseline_krauss_observations.csv").reset_index(drop=True)
syn=D[D.Source!="experimental_baseline"].reset_index(drop=True)
lo=B[INP].min().values;hi=B[INP].max().values;nf=dict(CoF=.03,FS=.02,Fade=.05,Recovery=.02,SWR=.05,Tmax=.03)
def gen(Btr,seed):
    rng=np.random.default_rng(seed);sur={r:RandomForestRegressor(n_estimators=300,min_samples_leaf=2,random_state=0).fit(Btr[INP].values,Btr[r].values) for r in RESP}
    c=pd.DataFrame({v:rng.uniform(lo[i],hi[i],2200) for i,v in enumerate(INP)})
    for r in RESP:c[r]=sur[r].predict(c[INP].values)+rng.normal(0,nf[r]*Btr[r].std(),2200)
    t=c[INP[:5]].sum(1);m=(t>=22)&(t<=40)&(c.SWR>0)&(c.Fade>=0)&(c.Fade<=100)&(c.Recovery>=0)&(c.Recovery<=100)&(c.CoF>=.25)&(c.CoF<=.6)
    return c[m].sample(n=min(1119,m.sum()),random_state=1).reset_index(drop=True)
def ann():return TT(make_pipeline(StandardScaler(),MLPRegressor(hidden_layer_sizes=(64,),alpha=1,activation="tanh",early_stopping=True,n_iter_no_change=20,max_iter=500,random_state=0)),transformer=StandardScaler())
M={"XGBoost":lambda:XGBRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0,verbosity=0),"Gradient Boosting":lambda:GradientBoostingRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0),"Random Forest":lambda:RandomForestRegressor(150,random_state=0),"ANN":ann}
fn="out/leak_preds.csv";rows=pd.read_csv(fn).to_dict("records") if os.path.exists(fn) else []
done={r["fold"] for r in rows};T0=time.time()
for k,(tr,te) in enumerate(GroupKFold(9).split(B,groups=B.Run.values)):
    if k in done:continue
    if time.time()-T0>200:break
    Btr,Bte=B.loc[tr],B.loc[te];sets={"Baseline only (72 rows)":Btr[INP+RESP],
        "Leaky: synthetic from all 81 (as in paper)":pd.concat([Btr[INP+RESP],syn[INP+RESP]],ignore_index=True),
        "Leak-free: synthetic regenerated from training runs":pd.concat([Btr[INP+RESP],gen(Btr,7+k)],ignore_index=True)}
    for sname,df in sets.items():
        for mn,mk in M.items():
            P={r:mk().fit(df[INP].values,df[r].values).predict(Bte[INP].values) for r in RESP}
            for i,idx in enumerate(Bte.index):rows.append(dict(fold=k,Setting=sname,Model=mn,row=idx,**{f"y_{r}":Bte.loc[idx,r] for r in RESP},**{f"p_{r}":P[r][i] for r in RESP}))
    pd.DataFrame(rows).to_csv(fn,index=False);print("fold",k,round(time.time()-T0),flush=True)
print(len({r["fold"] for r in rows}),"folds done")
