src=open("nsga_conv.py").read().split("import sys,os")[0];exec(src)
DC=pd.read_csv("out/dataset_consistent.csv")
SUR={r:XGBRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0,verbosity=0).fit(DC[INP],DC[r]) for r in RESP}
OBJ=["CoF","FS","Fade","Recovery","SWR","Tmax"];HIGH=[True,True,False,True,False,False]
conds={"Mild (0.4 MPa, 2 m/s, 100 °C)":[(0.4,2,100)],"Moderate (0.8 MPa, 5 m/s, 200 °C)":[(0.8,5,200)],"Severe (1.2 MPa, 8 m/s, 300 °C)":[(1.2,8,300)],
 "Envelope (3 × 3 × 3 grid of P, V, T0; mean)":[(p,v,t) for p in (0.4,0.8,1.2) for v in (2,5,8) for t in (100,200,300)]}
def resp_at(Xr,cs,agg="mean"):
    out={r:[] for r in RESP}
    for (P,V,T) in cs:
        d=pd.DataFrame(Xr,columns=INP[:5]);d["P"],d["V"],d["T0"]=P,V,T
        for r in RESP:out[r].append(SUR[r].predict(d[INP]))
    A={r:np.array(out[r]) for r in RESP}   # n_cond x n
    if agg=="mean":return {r:A[r].mean(0) for r in RESP}
    return {r:(A[r].min(0) if r in("CoF","FS","Recovery") else A[r].max(0)) for r in RESP}
class PF(Problem):
    def __init__(s,cs):super().__init__(n_var=5,n_obj=6,n_constr=3,xl=xl[:5],xu=xu[:5]);s.cs=cs
    def _evaluate(s,x,out,*a,**k):
        p=resp_at(x,s.cs);out["F"]=np.column_stack([-p["CoF"],-p["FS"],p["Fade"],-p["Recovery"],p["SWR"],p["Tmax"]]);tt=x.sum(1)
        # Tmax >= T0 in every condition of the envelope
        g=np.max([np.asarray(c[2]-SUR["Tmax"].predict(pd.concat([pd.DataFrame(x,columns=INP[:5]),pd.DataFrame({"P":c[0],"V":c[1],"T0":c[2]},index=range(len(x)))],axis=1)[INP])) for c in s.cs],axis=0)
        out["G"]=np.column_stack([22-tt,tt-40,g])
def front(cs,seed=1):
    alg=NSGA2(pop_size=120,sampling=FloatRandomSampling(),crossover=SBX(eta=15,prob=.9),mutation=PM(eta=20),eliminate_duplicates=True);r=minimize(PF(cs),alg,("n_gen",150),seed=seed,verbose=False)
    pf=pd.DataFrame(r.X,columns=INP[:5]);F=r.F
    for n,v in zip(OBJ,[-F[:,0],-F[:,1],F[:,2],-F[:,3],F[:,4],F[:,5]]):pf[n]=v
    return pf
def norm(pf):return pd.DataFrame({r:((pf[r]-pf[r].min())/(pf[r].max()-pf[r].min()+1e-12)) if h else 1-((pf[r]-pf[r].min())/(pf[r].max()-pf[r].min()+1e-12)) for r,h in zip(OBJ,HIGH)})
fronts={};picks={}
for nm,cs in conds.items():
    pf=front(cs);fronts[nm]=pf;s_=norm(pf).sum(1).where(pf.Fade>1.0,-1e9);picks[nm]=pf.loc[int(s_.argmax())];print(nm,len(pf),picks[nm][INP[:5]].round(2).to_dict(),flush=True)
# reference formulations
joint=pd.read_csv("out/consistent_nsga.csv").iloc[2];T8=dict(NR=15.559,NBR=9.447,SBR=4.053,EPDM=6.752,MSR=3.295)
forms={"Optimum for mild conditions":picks[list(conds)[0]],"Optimum for moderate conditions":picks[list(conds)[1]],"Optimum for severe conditions":picks[list(conds)[2]],"Envelope-robust optimum (mean over the grid)":picks[list(conds)[3]],
 "Joint optimum with free P, V, T0 (temperature-consistent data)":joint,"Formulation of Table 8 (original run)":pd.Series(T8)}
def score(x,cs,pf,agg="mean"):
    p=resp_at(np.array([[x[k] for k in INP[:5]]]),cs,agg);v=pd.Series({r:p[r][0] for r in RESP});s=0;
    for r,h in zip(OBJ,HIGH):
        z=(v[r]-pf[r].min())/(pf[r].max()-pf[r].min()+1e-12);z=z if h else 1-z;s+=min(max(z,0),1)
    return s,v
rows=[];
for fn,x in forms.items():
    row={"Formulation":fn,**{k:float(x[k]) for k in INP[:5]},"Total_rubber":float(sum(x[k] for k in INP[:5])),"Base":100-float(sum(x[k] for k in INP[:5]))}
    for cn,cs in conds.items():
        sc,v=score(x,cs,fronts[cn]);row["score "+cn.split(" (")[0]]=sc
        if cn.startswith("Envelope"):
            wc=resp_at(np.array([[x[k] for k in INP[:5]]]),cs,"worst");row["env_worst_CoF"]=wc["CoF"][0];row["env_worst_Fade"]=wc["Fade"][0];row["env_worst_SWR"]=wc["SWR"][0];row["env_mean_CoF"]=v["CoF"];row["env_mean_Fade"]=v["Fade"];row["env_mean_SWR"]=v["SWR"]
    rows.append(row)
R=pd.DataFrame(rows);R.to_csv("out/matched_conditions.csv",index=False);pd.set_option("display.width",260);print(R.round(2).to_string())
# responses of the matched optima at their own conditions
own=[]
for cn,cs in list(conds.items())[:3]:
    x=picks[cn];p=resp_at(np.array([[x[k] for k in INP[:5]]]),cs);own.append(dict(Condition=cn,**{r:p[r][0] for r in RESP}))
pd.DataFrame(own).to_csv("out/matched_own_responses.csv",index=False);print(pd.DataFrame(own).round(2).to_string())
