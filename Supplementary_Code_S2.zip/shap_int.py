from common import *
import shap, itertools, statsmodels.api as sm
from xgboost import XGBRegressor
from scipy.stats import spearmanr
from sklearn.preprocessing import StandardScaler
Z=pd.DataFrame(StandardScaler().fit_transform(X),columns=INP)
pairs=list(itertools.combinations(range(8),2));rows=[];tops={}
for resp in RESP:
    y=D[resp].values
    m=XGBRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0,verbosity=0).fit(D[INP],y)
    iv=shap.TreeExplainer(m).shap_interaction_values(D[INP])   # n x 8 x 8
    f=m.predict(D[INP]);varf=f.var()
    main=np.abs(iv[:,range(8),range(8)]).mean(0).sum()
    S={p:np.abs(2*iv[:,p[0],p[1]]).mean() for p in pairs}   # pair strength = Phi_ij+Phi_ji
    V={p:(2*iv[:,p[0],p[1]]).var()/varf*100 for p in pairs}
    tot=main+sum(S.values())
    # ANOVA on continuous design: main + quadratic + all 2-way products
    df=Z.copy()
    for i in INP: df[i+"^2"]=df[i]**2
    for a,b in pairs: df[f"{INP[a]}x{INP[b]}"]=Z[INP[a]]*Z[INP[b]]
    ols=sm.OLS(y-y.mean(),sm.add_constant(df)).fit()
    F=ols.tvalues**2; an=pd.DataFrame({"sum_sq":F*ols.mse_resid,"F":F,"PR(>F)":ols.pvalues}); sst=((y-y.mean())**2).sum()
    for a,b in pairs:
        n=f"{INP[a]}x{INP[b]}"
        rows.append(dict(Response=resp,Pair=f"{INP[a]}×{INP[b]}",SHAP_int_mean_abs=S[(a,b)],SHAP_share_pct=S[(a,b)]/tot*100,
            SHAP_var_pct=V[(a,b)],ANOVA_SS_pct=an.loc[n,"sum_sq"]/sst*100,ANOVA_F=an.loc[n,"F"],ANOVA_p=an.loc[n,"PR(>F)"]))
    rows[-28]["_x"]=0
    ent=dict(Response=resp,main_share=main/tot*100,inter_share=(1-main/tot)*100,
        anova_main_pct=an.loc[INP,"sum_sq"].sum()/sst*100,anova_quad_pct=an.loc[[i+"^2" for i in INP],"sum_sq"].sum()/sst*100,
        anova_int_pct=an.loc[[f"{INP[a]}x{INP[b]}" for a,b in pairs],"sum_sq"].sum()/sst*100,R2_lin=ols.rsquared)
    tops[resp]=ent
R=pd.DataFrame(rows).drop(columns="_x",errors="ignore");R.to_csv("out/shap_vs_anova_pairs.csv",index=False)
T=pd.DataFrame(tops).T;
rho=[]
for resp in RESP:
    r=R[R.Response==resp];rho.append(spearmanr(r.SHAP_int_mean_abs,r.ANOVA_SS_pct)[0])
T["spearman_SHAP_vs_ANOVA"]=rho;T.to_csv("out/shap_vs_anova_summary.csv")
pd.set_option("display.width",200);print(T.round(3))
for resp in ["CoF","SWR","Fade"]:
    print(resp);print(R[R.Response==resp].sort_values("SHAP_int_mean_abs",ascending=False).head(6).round(4).to_string())
