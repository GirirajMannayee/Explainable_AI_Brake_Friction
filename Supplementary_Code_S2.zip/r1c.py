from common import *
import warnings;warnings.filterwarnings("ignore")
from scipy.stats import spearmanr
from sklearn.ensemble import RandomForestRegressor
B=D[D.Source=="experimental_baseline"].reset_index(drop=True);S=D[D.Source!="experimental_baseline"].reset_index(drop=True)
Rg=8.314
def tests(df):
    o={};dT=df.Tmax-df.T0;q=df.CoF*df.P*df.V
    o["n"]=len(df);o["dT<=0 (%)"]=(dT<=0).mean()*100
    o["rho(dT, mu*P*V)"]=spearmanr(dT,q)[0];o["rho(dT,P)"]=spearmanr(dT,df.P)[0];o["rho(dT,V)"]=spearmanr(dT,df.V)[0]
    m=dT>0;b=np.polyfit(np.log(q[m]),np.log(dT[m]),1);o["exponent n in dT~(muPV)^n"]=b[0]
    A=np.column_stack([np.ones(len(df)),df.T0,q]);c=np.linalg.lstsq(A,df.Tmax.values,rcond=None)[0];o["slope Tmax vs T0 (energy-balance expects ~1)"]=c[1]
    o["rho(CoF,Tmax)"]=spearmanr(df.CoF,df.Tmax)[0];o["rho(Fade,Tmax)"]=spearmanr(df.Fade,df.Tmax)[0];o["rho(Recovery,Tmax)"]=spearmanr(df.Recovery,df.Tmax)[0];o["rho(SWR,Tmax)"]=spearmanr(df.SWR,df.Tmax)[0]
    TK=df.Tmax+273.15;Aa=np.column_stack([np.ones(len(df)),np.log(df.P*df.V),-1/(Rg*TK)]);y=np.log(df.SWR.clip(lower=1e-3))
    c=np.linalg.lstsq(Aa,y.values,rcond=None)[0];pred=Aa@c;o["apparent Ea in ln SWR (kJ/mol)"]=c[2]/1000;o["exponent of P*V on SWR"]=c[1];o["R2 of Arrhenius+PV fit"]=1-((y-pred)**2).sum()/((y-y.mean())**2).sum()
    return o
T=pd.DataFrame({"baseline (81)":tests(B),"synthetic (1119)":tests(S),"all (1200)":tests(D)});pd.set_option("display.width",200);print(T.round(3).to_string());T.to_csv("out/physical_consistency.csv")
# local derivative sign tests on the generator surface (RF fitted to the 81 baseline rows)
Bb=pd.read_csv("dataset_81_baseline_krauss_observations.csv");lo=Bb[INP].min().values;hi=Bb[INP].max().values
rng=np.random.default_rng(3);X=rng.uniform(lo,hi,(6000,8));X=X[X[:,:5].sum(1)<=40];n=len(X)
sur={r:RandomForestRegressor(n_estimators=300,min_samples_leaf=2,random_state=0).fit(Bb[INP].values,Bb[r].values) for r in RESP}
exp=[("T0","CoF",-1),("T0","Fade",1),("T0","Recovery",-1),("T0","SWR",1),("T0","Tmax",1),("P","Tmax",1),("V","Tmax",1),("P","SWR",1),("V","SWR",1),("P","CoF",-1),("V","CoF",-1)]
rows=[]
for v,r,sg in exp:
    j=INP.index(v);h=(hi[j]-lo[j])*0.25;A=X.copy();Bx=X.copy();A[:,j]=np.clip(X[:,j]-h/2,lo[j],hi[j]);Bx[:,j]=np.clip(X[:,j]+h/2,lo[j],hi[j])
    d=sur[r].predict(Bx)-sur[r].predict(A);rows.append(dict(factor=v,response=r,expected="increase" if sg>0 else "decrease",frac_expected_sign=(np.sign(d)==sg).mean()*100,frac_zero=(d==0).mean()*100,mean_change=d.mean()))
L=pd.DataFrame(rows);L.to_csv("out/derivative_signs.csv",index=False);print(L.round(2).to_string())
# factor-ranking inheritance: standardised linear partial shares, baseline vs synthetic
def share(df,r):
    Z=(df[INP]-df[INP].mean())/df[INP].std();c=np.linalg.lstsq(np.column_stack([np.ones(len(df)),Z.values]),df[r].values,rcond=None)[0][1:];return pd.Series(c**2/np.sum(c**2),INP)
rk=[]
for r in RESP:
    a=share(B,r);b=share(S,r);rho=spearmanr(a,b)[0];rk.append(dict(Response=r,rho=rho,top3_baseline=", ".join(a.sort_values(ascending=False).index[:3]),top3_synthetic=", ".join(b.sort_values(ascending=False).index[:3])))
K=pd.DataFrame(rk);K.to_csv("out/ranking_inheritance.csv",index=False);print(K.round(3).to_string())
# effect of adding constraint (vi) Tmax>=T0 to the candidate filter
rng=np.random.default_rng(7);import itertools
sur2={r:RandomForestRegressor(n_estimators=300,min_samples_leaf=2,random_state=0).fit(Bb[INP].values,Bb[r].values) for r in RESP}
c=pd.DataFrame({v:rng.uniform(lo[i],hi[i],2200) for i,v in enumerate(INP)})
for r in RESP:c[r]=sur2[r].predict(c[INP].values)+rng.normal(0,{"CoF":.03,"FS":.02,"Fade":.05,"Recovery":.02,"SWR":.05,"Tmax":.03}[r]*Bb[r].std(),2200)
t=c[INP[:5]].sum(1);m=(t>=22)&(t<=40)&(c.SWR>0)&(c.Fade>=0)&(c.Fade<=100)&(c.Recovery>=0)&(c.Recovery<=100)&(c.CoF>=.25)&(c.CoF<=.6)
print("retained (i-v):",m.sum(),"| of which Tmax<T0:",(m&(c.Tmax<c.T0)).sum(),"| retained with (vi) Tmax>=T0:",(m&(c.Tmax>=c.T0)).sum(),"of 2200")
