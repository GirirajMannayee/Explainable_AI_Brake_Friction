from common import *
from xgboost import XGBRegressor
import warnings;warnings.filterwarnings("ignore")
D["tot"]=D[["NR","NBR","SBR","EPDM","MSR"]].sum(1);b=D[D.Source=="experimental_baseline"];s=D[D.Source!="experimental_baseline"]
print("baseline rows tot>40:",(b.tot>40).sum(),"of",len(b),"| tot range",b.tot.min(),b.tot.max(),"| synth tot range",s.tot.min().round(2),s.tot.max().round(2))
print("Fade<0 baseline",(b.Fade<0).sum(),"synth",(s.Fade<0).sum(),"| Tmax<T0 baseline",(b.Tmax<b.T0).sum(),"synth",(s.Tmax<s.T0).sum(),"| CoF out of .25-.6 baseline",((b.CoF<.25)|(b.CoF>.6)).sum())
print("design rows tot:",sorted(set(b.groupby(["NR","NBR","SBR","EPDM","MSR"]).ngroups for _ in [0])), b.groupby(["NR","NBR","SBR","EPDM","MSR"]).tot.first().describe().round(1).to_dict())
# ---- mechanism-supporting numbers from the 81 observations (level means)
for r,f in [("CoF","NR"),("CoF","T0"),("SWR","T0"),("SWR","V"),("SWR","NBR"),("SWR","EPDM"),("Fade","T0"),("Tmax","V"),("Tmax","P")]:
    print(r,f,b.groupby(f)[r].mean().round(3).to_dict())
# ---- 1200-set: slope of NBR on SWR and NR on CoF within T0 terciles (standardised OLS per tercile)
D["Tc"]=pd.qcut(D.T0,3,labels=["low","mid","high"])
for r,f in [("SWR","NBR"),("SWR","EPDM"),("SWR","NR"),("CoF","NR"),("CoF","NBR"),("CoF","SBR")]:
    out={}
    for t,g in D.groupby("Tc"):
        A=np.column_stack([np.ones(len(g))]+[(g[c]-g[c].mean())/g[c].std() for c in INP]);y=g[r].values
        out[t]=round(np.linalg.lstsq(A,y,rcond=None)[0][1+INP.index(f)],4)
    print(r,f,"std slope per T0 tercile",out)
# ---- C. formulation x condition coupling with XGB surrogates
sur={r:XGBRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0,verbosity=0).fit(D[INP],D[r]) for r in RESP}
rs=np.random.default_rng(5);N=30000;F=pd.DataFrame(rs.uniform([8,5,4,3,2],[16,11,10,7,6],(N,5)),columns=INP[:5]);F=F[(F.sum(1)>=22)&(F.sum(1)<=40)].reset_index(drop=True);print("feasible formulations",len(F))
conds={"mild (T0=100C, V=2, P=0.4)":(0.4,2,100),"moderate (200C,5 m/s,0.8)":(0.8,5,200),"severe (T0=300C, V=8, P=1.2)":(1.2,8,300),"hot+fast, low P (300C,8,0.4)":(0.4,8,300)}
rows=[]
for k,(P,V,T) in conds.items():
    X=F.copy();X["P"],X["V"],X["T0"]=P,V,T;pr={r:sur[r].predict(X[INP]) for r in RESP}
    sw=pr["SWR"];i=sw.argmin();j=sw.argmax();q=np.percentile(sw,[5,50,95])
    rows.append(dict(cond=k,SWR_best=sw.min(),SWR_p5=q[0],SWR_med=q[1],SWR_p95=q[2],SWR_worst=sw.max(),CoF_at_bestSWR=pr["CoF"][i],CoF_med=np.median(pr["CoF"]),Fade_at_best=pr["Fade"][i],Tmax_med=np.median(pr["Tmax"]),
      NR=F.NR[i],NBR=F.NBR[i],SBR=F.SBR[i],EPDM=F.EPDM[i],MSR=F.MSR[i],corr_SWR_CoF=np.corrcoef(sw,pr["CoF"])[0,1]))
C=pd.DataFrame(rows);pd.set_option("display.width",250);print(C.round(3).T);C.to_csv("out/coupling.csv",index=False)
# effect of each rubber on SWR at severe vs mild: slope per +1 wt% via partial-dependence on feasible set
for k in ["mild (T0=100C, V=2, P=0.4)","severe (T0=300C, V=8, P=1.2)"]:
    P,V,T=conds[k];X=F.copy();X["P"],X["V"],X["T0"]=P,V,T;sw=sur["SWR"].predict(X[INP])
    print(k,{c:round(np.polyfit(F[c],sw,1)[0],3) for c in INP[:5]})
# operating-condition lever: median SWR if T0 100 vs 300 at V=8,P=.8 for median formulation
X=F.copy();X["P"],X["V"]=0.8,8
for T in (100,200,300):
    X["T0"]=T;sw=sur["SWR"].predict(X[INP]);print("V=8,P=.8,T0",T,"SWR med",round(np.median(sw),2),"best",round(sw.min(),2))
