src=open("nsga_conv.py").read().split("import sys,os")[0];exec(src)
import shap
from sklearn.model_selection import KFold
OBJ=["CoF","FS","Fade","Recovery","SWR","Tmax"];HIGH=[True,True,False,True,False,False]
def front(seed,ng,pop):
    r,_=run(seed,ng,pop,10**6);pf=pd.DataFrame(r.X,columns=INP);F=r.F
    for n,v in zip(OBJ,[-F[:,0],-F[:,1],F[:,2],-F[:,3],F[:,4],F[:,5]]):pf[n]=v
    return pf
def norm(pf):
    N=pd.DataFrame(index=pf.index)
    for r,h in zip(OBJ,HIGH):
        v=(pf[r]-pf[r].min())/(pf[r].max()-pf[r].min()+1e-12);N[r]=v if h else 1-v
    return N
def pick(pf,N,w):
    s=(N.values*np.asarray(w)).sum(1);s=np.where(pf.Fade.values>1.0,s,-1e9);return int(np.argmax(s))
fr={"pop120_gen150":pd.read_csv("out/pareto_150gen_8var.csv"),"pop240_gen300":front(1,300,240)}
fr["pop240_gen300"].to_csv("out/pareto_240_300.csv",index=False)
T8=dict(NR=15.559,NBR=9.447,SBR=4.053,EPDM=6.752,MSR=3.295,P=.418,V=2.35,T0=140.2)
rows=[];rs=np.random.default_rng(0);W=rs.dirichlet(np.ones(6),5000)
for name,pf in fr.items():
    N=norm(pf);i0=pick(pf,N,np.ones(6));b=pf.loc[i0]
    print(name,"equal-weight pick:",b[INP+OBJ].round(3).to_dict())
    sel=np.array([pick(pf,N,w) for w in W]);u,cnt=np.unique(sel,return_counts=True)
    print(" distinct picks over 5000 Dirichlet weights:",len(u),"| share same as equal-weight pick:",round((sel==i0).mean()*100,1),"%| top share",round(cnt.max()/50,1),"%")
    S=pf.loc[sel,OBJ];print(" selected objective 5-95%:",{r:(round(S[r].quantile(.05),3),round(S[r].quantile(.95),3)) for r in OBJ})
    print(" selected formulation 5-95%:",{c:(round(pf.loc[sel,c].quantile(.05),1),round(pf.loc[sel,c].quantile(.95),1)) for c in INP})
    # OAT emphasis x3 and drop-one
    for k,r in enumerate(OBJ):
        for tag,fac in [("x3",3.0),("x0",0.0)]:
            w=np.ones(6);w[k]=fac;j=pick(pf,N,w);q=pf.loc[j]
            rows.append(dict(front=name,scenario=f"{r} {tag}",**{o:q[o] for o in OBJ},**{c:q[c] for c in INP},same=(j==i0)))
    rows.append(dict(front=name,scenario="equal weights (baseline)",**{o:b[o] for o in OBJ},**{c:b[c] for c in INP},same=True))
    # other scalarisations
    Nv=N.values;ok=pf.Fade.values>1.0
    d=np.where(ok,np.sqrt(((1-Nv)**2).sum(1)),1e9);j=int(np.argmin(d));q=pf.loc[j];rows.append(dict(front=name,scenario="TOPSIS (Euclid. dist. to ideal)",**{o:q[o] for o in OBJ},**{c:q[c] for c in INP},same=(j==i0)))
    d=np.where(ok,(1-Nv).max(1),1e9);j=int(np.argmin(d));q=pf.loc[j];rows.append(dict(front=name,scenario="Chebyshev (min-max regret)",**{o:q[o] for o in OBJ},**{c:q[c] for c in INP},same=(j==i0)))
    rows.append(dict(front=name,scenario="_dirichlet_summary",CoF=len(u),FS=(sel==i0).mean()*100,Fade=cnt.max()/50))
pd.set_option("display.width",250);R=pd.DataFrame(rows);R.to_csv("out/weight_sensitivity.csv",index=False)
print(R[R.front=="pop120_gen150"].round(3).to_string())
# Table 8 solution evaluated by our surrogates, vs 120-front
x=pd.DataFrame([T8]);p={r:float(sur[r].predict(x[INP])[0]) for r in RESP};print("Table8 under surrogates",{k:round(v,3) for k,v in p.items()})
pf=fr["pop120_gen150"];Fv=np.column_stack([-p["CoF"],-p["FS"],p["Fade"],-p["Recovery"],p["SWR"],p["Tmax"]])
Fo=np.column_stack([-pf.CoF,-pf.FS,pf.Fade,-pf.Recovery,pf.SWR,pf.Tmax]);dom=((Fo<=Fv).all(1)&(Fo<Fv).any(1)).sum();print("front members dominating Table-8 solution:",dom)
Nt=norm(pd.concat([pf,pd.DataFrame([{**T8,**p}])],ignore_index=True));sc=Nt.sum(1);print("Table-8 equal-weight score",round(sc.iloc[-1],3),"rank among front+it",int((sc>sc.iloc[-1]).sum())+1,"max front score",round(sc.iloc[:-1].max(),3))
# ---- over-40 sensitivity
D["tot"]=D[INP[:5]].sum(1);keep=~((D.Source=="experimental_baseline")&(D.tot>40))
print("rows removed",(~keep).sum())
def cvr2(df,mk):
    kf=list(KFold(5,shuffle=True,random_state=0).split(df));out=[]
    for r in RESP:
        y=df[r].values;P=np.zeros(len(y))
        for a,b in kf:P[b]=mk().fit(df[INP].values[a],y[a]).predict(df[INP].values[b])
        out.append(1-((y-P)**2).sum()/((y-y.mean())**2).sum())
    return np.mean(out)
mk=lambda:XGBRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0,verbosity=0)
print("XGB CV R2 all 1200:",round(cvr2(D,mk),4),"| without 18 rows >40 wt%:",round(cvr2(D[keep].reset_index(drop=True),mk),4))
for resp in ["CoF","SWR"]:
    o=[]
    for df in (D,D[keep]):
        m=XGBRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0,verbosity=0).fit(df[INP],df[resp]);sv=np.abs(shap.TreeExplainer(m).shap_values(df[INP])).mean(0);o.append(pd.Series(sv,INP).sort_values(ascending=False))
    print(resp,"SHAP order all:",list(o[0].index[:4]),"| w/o rows:",list(o[1].index[:4]),"| top-share",round(o[0].iloc[0]/o[0].sum()*100,1),round(o[1].iloc[0]/o[1].sum()*100,1))
