from common import *
import warnings;warnings.filterwarnings("ignore")
import shap
from scipy.stats import spearmanr
from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBRegressor
B=pd.read_csv("dataset_81_baseline_krauss_observations.csv");lo=B[INP].min().values;hi=B[INP].max().values
nf=dict(CoF=.03,FS=.02,Fade=.05,Recovery=.02,SWR=.05,Tmax=.03)
def gen_perm(perm,seed=7):
    # label-permuted generator: the forest is trained with factor columns relabelled (perm maps new column j <- old column perm[j]), samples drawn in the ORIGINAL box
    rng=np.random.default_rng(seed);Xb=B[INP].values[:,perm]
    sur={r:RandomForestRegressor(n_estimators=300,min_samples_leaf=2,random_state=0).fit(Xb,B[r].values) for r in RESP}
    X=np.column_stack([rng.uniform(lo[i],hi[i],2200) for i in range(8)]);c=pd.DataFrame(X,columns=INP)
    for r in RESP:c[r]=sur[r].predict(X)+rng.normal(0,nf[r]*B[r].std(),2200)
    t=c[INP[:5]].sum(1);m=(t>=22)&(t<=40)&(c.SWR>0)&(c.Fade>=0)&(c.Fade<=100)&(c.Recovery>=0)&(c.Recovery<=100)&(c.CoF>=.25)&(c.CoF<=.6)
    return c[m].sample(n=1119,random_state=1).reset_index(drop=True)
def agree(S):
    out={}
    for r in RESP:
        y=S[r].values;Z=(S[INP]-S[INP].mean())/S[INP].std();A=np.column_stack([np.ones(len(S)),Z.values,Z.values**2]);c=np.linalg.lstsq(A,y,rcond=None)[0]
        an=pd.Series(c[1:9]**2*(Z.values**2).sum(0)+c[9:]**2*((Z.values**2)**2).sum(0),INP)   # main + quadratic contribution per factor (approx. SS)
        m=XGBRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0,verbosity=0).fit(S[INP],y);sv=pd.Series(np.abs(shap.TreeExplainer(m).shap_values(S[INP])).mean(0),INP)
        out[r]=(spearmanr(an,sv)[0],sv.sort_values(ascending=False).index[:3].tolist())
    return out
# physical expectation used by the authors: T0, V, P, NR among leading factors for wear/thermal responses
idx=lambda names:[INP.index(n) for n in names]
cases={"Original generator (physical labels)":list(range(8)),
 "Permutation 1: NR<->EPDM, NBR<->MSR (rubber labels swapped)":idx(["EPDM","MSR","SBR","NR","NBR","P","V","T0"]),
 "Permutation 2: T0<->MSR, P<->V (condition labels swapped)":idx(["NR","NBR","SBR","EPDM","T0","V","P","MSR"]),
 "Permutation 3: random relabelling of all eight factors":list(np.random.default_rng(5).permutation(8))}
rows=[]
for nm,perm in cases.items():
    S=gen_perm(perm) if perm!=list(range(8)) else D[D.Source!="experimental_baseline"].reset_index(drop=True)[INP+RESP]
    a=agree(S);rows.append(dict(Generator=nm,mean_rho=np.mean([v[0] for v in a.values()]),min_rho=min(v[0] for v in a.values()),**{f"top3_{r}":", ".join(a[r][1]) for r in ["CoF","SWR","Tmax"]}))
    print(nm,round(rows[-1]["mean_rho"],3),round(rows[-1]["min_rho"],3),rows[-1]["top3_CoF"],"|",rows[-1]["top3_SWR"],"|",rows[-1]["top3_Tmax"])
pd.DataFrame(rows).to_csv("out/circularity_control.csv",index=False)
# total rubber vs blend composition importance (reparametrisation: total rubber T = base dilution, fractions f_i = R_i / T)
Dd=D[INP+RESP].copy();T=Dd[INP[:5]].sum(1);R2=pd.DataFrame({"T_rubber":T,**{f"f_{c}":Dd[c]/T for c in INP[:4]},"P":Dd.P,"V":Dd.V,"T0":Dd.T0});rows=[]
for r in RESP:
    m=XGBRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0,verbosity=0).fit(R2,Dd[r]);sv=pd.Series(np.abs(shap.TreeExplainer(m).shap_values(R2)).mean(0),R2.columns);sh=sv/sv.sum()*100
    rows.append(dict(Response=r,**{k:sh[k] for k in R2.columns},blend_share=sh[[c for c in R2.columns if c.startswith("f_")]].sum(),cond_share=sh[["P","V","T0"]].sum()))
Q=pd.DataFrame(rows);Q.to_csv("out/total_vs_blend.csv",index=False);print(Q.round(1).to_string())
print("corr(T_rubber, base)= -1 by construction; base range",(100-T).min(),(100-T).max())
