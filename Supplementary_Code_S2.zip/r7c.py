from common import *
import warnings;from sklearn.exceptions import ConvergenceWarning
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from xgboost import XGBRegressor
tr,te=train_test_split(np.arange(1200),test_size=.2,random_state=0);sc=StandardScaler().fit(X[tr]);Xtr,Xte=sc.transform(X[tr]),sc.transform(X[te])
def fit(cfg,y_scaled,resp,n=None):
    y=D[resp].values;ym,ys=(y[tr].mean(),y[tr].std()) if y_scaled else (0,1);idx=tr if n is None else tr[:n]
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always");m=MLPRegressor(random_state=0,**cfg).fit(sc.transform(X[idx]),(y[idx]-ym)/ys)
    p=m.predict(Xte)*ys+ym;yt=y[te];return m,1-((yt-p)**2).sum()/((yt-yt.mean())**2).sum(),any(issubclass(x.category,ConvergenceWarning) for x in w)
orig=dict(hidden_layer_sizes=(64,32),activation="relu",max_iter=3000)
cfgs={"Original (64-32, ReLU, raw targets)":(orig,False),"Original configuration, standardized targets":(orig,True),
 "Tuned (64, tanh, α = 1, early stopping, standardized targets)":(dict(hidden_layer_sizes=(64,),activation="tanh",alpha=1,early_stopping=True,n_iter_no_change=20,max_iter=500),True)}
rows=[]
for name,(cfg,ys) in cfgs.items():
    for resp in RESP:
        m,r2,cw=fit(cfg,ys,resp);rows.append(dict(Config=name,Response=resp,max_iter=cfg["max_iter"],n_iter=m.n_iter_,stopped_before_max=m.n_iter_<cfg["max_iter"],final_train_loss=m.loss_,best_val=getattr(m,"best_validation_score_",np.nan),R2_test=r2,conv_warning=cw))
C=pd.DataFrame(rows);C.to_csv("out/ann_convergence.csv",index=False);pd.set_option("display.width",220);print(C.round(4).to_string())
# learning curves: mean R2 over six responses vs training size on the same 240-sample test set
sizes=[50,100,200,400,800,960];lc=[]
for n in sizes:
    for name,(cfg,ys) in [("ANN, original (raw targets)",(orig,False)),("ANN, tuned (standardized targets)",(cfgs["Tuned (64, tanh, α = 1, early stopping, standardized targets)"][0],True))]:
        r2=[fit(cfg,ys,r,n)[1] for r in RESP];lc.append(dict(Model=name,n=n,meanR2=np.mean(r2),R2_CoF=r2[0],R2_FS=r2[1]))
    r2=[]
    for r in RESP:
        y=D[r].values;m=XGBRegressor(n_estimators=300,max_depth=4,learning_rate=.05,random_state=0,verbosity=0).fit(X[tr[:n]],y[tr[:n]]);p=m.predict(X[te]);yt=y[te];r2.append(1-((yt-p)**2).sum()/((yt-yt.mean())**2).sum())
    lc.append(dict(Model="XGBoost",n=n,meanR2=np.mean(r2),R2_CoF=r2[0],R2_FS=r2[1]))
L=pd.DataFrame(lc);L.to_csv("out/ann_learning_curve.csv",index=False);print(L.pivot(index="n",columns="Model",values="meanR2").round(3).to_string())
